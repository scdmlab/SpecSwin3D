﻿import sys
import os
import json
import contextlib
import itertools
from datetime import datetime
import glob
from tqdm import tqdm
import numpy as np
import argparse
from sklearn.cluster import KMeans
from sklearn.metrics import pairwise_distances

# Add parent directory to path
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from config import BASE_DIR, CHECKPOINT_DIR

# 🔥 自动修复路径问题：适配 Colab/Linux 和 Windows
project_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

if os.name == 'posix':  # ✅ Colab / Linux 环境
    print(f"🐧 检测到 Linux/Colab 环境，强制使用相对路径")
    CHECKPOINT_DIR = os.path.join(project_root, "checkpoints")
    BASE_DIR = os.path.join(project_root, "dataset")
    print(f"   ➡️ 新 CHECKPOINT_DIR: {CHECKPOINT_DIR}")
    print(f"   ➡️ 新 BASE_DIR: {BASE_DIR}")

elif os.name == 'nt':   # Windows 环境
    drive, _ = os.path.splitdrive(CHECKPOINT_DIR)
    if drive and not os.path.exists(drive):
        print(f"⚠️ 检测到配置的驱动器 {drive} 不存在，切换到相对路径模式")
        CHECKPOINT_DIR = os.path.join(project_root, "checkpoints")
        BASE_DIR = os.path.join(project_root, "dataset")
        print(f"   ➡️ 新 CHECKPOINT_DIR: {CHECKPOINT_DIR}")
        print(f"   ➡️ 新 BASE_DIR: {BASE_DIR}")

import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import Dataset, DataLoader
from torch.utils.tensorboard import SummaryWriter

# Import utils (Ensure these files exist in train/ or root)
from denormalize_utils import denormalize_prediction
from losses import AnchorConsistencyLoss, SAMLoss

# Import model
from models.swin_unetr_local import SwinUNETR_Local as SwinUNETR

class SwinUNETR_SingleBand(nn.Module):
    """单波段光谱重建模型"""
    def __init__(self, in_channels=16, img_size=(128, 128), spatial_dims=2, use_anchor=False, patch_size=2, downsample="combinatorial"):
        super().__init__()
        self.use_anchor = use_anchor
        self.model = SwinUNETR(
            img_size=img_size,
            in_channels=in_channels,
            feature_size=48,
            spatial_dims=spatial_dims,
            use_checkpoint=False,
            use_anchor_head=use_anchor,
            anchor_k=10,
            patch_size=patch_size,
            downsample=downsample
        )
    
    def forward(self, x):
        if self.use_anchor:
            out = self.model(x) # Returns (logits, anchor_out)
            logits, anchor_out = out
        else:
            logits = self.model(x) # Returns logits
            anchor_out = None
            
        if logits.dim() == 5 and logits.shape[2] > 1:
             logits = logits.mean(dim=2, keepdim=True)
             
        if self.use_anchor:
            return logits, anchor_out
        return logits

class SingleBandDataset(Dataset):
    """单波段光谱重建数据集"""
    def __init__(self, input_dir, label_dir, target_band_idx, use_3d=False, return_anchor=False):
        self.input_dir = input_dir
        self.label_dir = label_dir
        self.target_band_idx = target_band_idx
        self.return_anchor = return_anchor
        
        # Load PCA stats if needed
        self.pca_components = None
        self.pca_mean = None
        if self.return_anchor:
            possible_pca_paths = [
                os.path.join(BASE_DIR, 'pca_stats.pt'),
                os.path.join(os.path.dirname(BASE_DIR), 'pca_stats.pt'),
                os.path.join(project_root, 'dataset', 'pca_stats.pt')
            ]
            
            pca_path = None
            for path in possible_pca_paths:
                if os.path.exists(path):
                    pca_path = path
                    break
            
            if pca_path:
                pca_stats = torch.load(pca_path, map_location='cpu')
                self.pca_components = pca_stats['components'].float()
                self.pca_mean = pca_stats['mean'].float()
                print(f"✅ 已加载PCA统计数据: {pca_path}")
            else:
                print(f"⚠️ 未找到PCA统计数据，已尝试路径: {possible_pca_paths}")
                print(f"⚠️ 将使用微小非零向量作为Anchor Target")
        
        self.input_bands = [30, 20, 9, 40, 52]
        
        if target_band_idx in self.input_bands:
            raise ValueError(f"目标波段 {target_band_idx} 是输入波段，不能作为重建目标！输入波段: {self.input_bands}")
        
        self.input_files = sorted(glob.glob(os.path.join(input_dir, "*.pt")))
        self.label_files = sorted(glob.glob(os.path.join(label_dir, "*.pt")))
        
        assert len(self.input_files) == len(self.label_files), \
            f"输入文件数({len(self.input_files)})与标签文件数({len(self.label_files)})不匹配"
        
        # 获取归一化参数
        sample_label = torch.load(self.label_files[0], map_location='cpu')
        if isinstance(sample_label, dict) and 'norm_params' in sample_label:
            label_band_indices = sample_label['band_indices']
            if target_band_idx in label_band_indices:
                band_pos_in_label = label_band_indices.index(target_band_idx)
                self.norm_params = sample_label['norm_params'][band_pos_in_label]
            else:
                self.norm_params = None
        else:
            self.norm_params = None
        
        print(f"📊 单波段数据集: {len(self.input_files)} 样本, 目标波段: {target_band_idx}")
        
        self.use_3d = use_3d
        if self.use_3d:
            self.depth_indices = self._generate_balanced_32_depth_indices()

    def _generate_balanced_32_depth_indices(self):
        """生成 32 个深度通道的组合索引，采用 6-7-6-7-6 结构"""
        indices = [0, 1, 2, 3, 4]
        pool_L1 = list(itertools.combinations(indices, 1))
        pool_L2 = list(itertools.combinations(indices, 2))
        pool_L3 = list(itertools.combinations(indices, 3))
        pool_L4 = list(itertools.combinations(indices, 4))
        pool_L5 = list(itertools.combinations(indices, 5)) * 2
        
        def make_block_A():
            return [pool_L1.pop(0), pool_L2.pop(0), pool_L3.pop(0), pool_L4.pop(0), pool_L2.pop(0), pool_L3.pop(0)]
            
        def make_block_B():
            return [pool_L1.pop(0), pool_L2.pop(0), pool_L3.pop(0), pool_L5.pop(0), pool_L4.pop(0), pool_L2.pop(0), pool_L3.pop(0)]

        final_sequence = []
        final_sequence.extend(make_block_A())
        final_sequence.extend(make_block_B())
        final_sequence.extend(make_block_A())
        final_sequence.extend(make_block_B())
        final_sequence.extend(make_block_A())
        return final_sequence
    
    def get_norm_params(self):
        return self.norm_params
    
    def __len__(self):
        return len(self.input_files)
    
    def __getitem__(self, idx):
        input_data = torch.load(self.input_files[idx], map_location='cpu')
        label_data = torch.load(self.label_files[idx], map_location='cpu')
        
        input_tensor = input_data['input'] if isinstance(input_data, dict) else input_data
        label_tensor = label_data['label'] if isinstance(label_data, dict) else label_data
        
        input_tensor = input_tensor.float()
        label_tensor = label_tensor.float()
        
        if self.use_3d:
            if input_tensor.dim() == 3:
                if input_tensor.shape[0] == 5:
                    channels_32 = []
                    for indices in self.depth_indices:
                        selected_bands = input_tensor[list(indices), :, :] 
                        mean_band = selected_bands.mean(dim=0, keepdim=True)
                        channels_32.append(mean_band)
                    input_tensor = torch.cat(channels_32, dim=0) 
                    input_tensor = input_tensor.unsqueeze(0)     
                elif input_tensor.shape[0] == 16:
                    input_tensor = input_tensor.permute(1, 2, 0)
                    input_tensor = torch.cat([input_tensor, input_tensor], dim=2)
                    input_tensor = input_tensor.unsqueeze(0).permute(0, 3, 1, 2)
        
        if isinstance(label_data, dict) and 'band_indices' in label_data:
            label_band_indices = label_data['band_indices']
            if self.target_band_idx in label_band_indices:
                band_pos_in_label = label_band_indices.index(self.target_band_idx)
                target_band = label_tensor[band_pos_in_label:band_pos_in_label+1]
            else:
                raise ValueError(f"目标波段 {self.target_band_idx} 不在标签数据中")
        else:
            target_band = label_tensor[self.target_band_idx:self.target_band_idx+1]

        if self.use_3d:
            if target_band.dim() == 2:
                target_band = target_band.unsqueeze(0).unsqueeze(0)
            elif target_band.dim() == 3:
                target_band = target_band.unsqueeze(0)
            
            # if input_tensor.shape[1] == 32:
            #      target_band = target_band.repeat(1, 32, 1, 1)
        
        if self.return_anchor:
            if self.pca_components is not None and label_tensor.shape[0] == 219:
                flat_label = label_tensor.view(219, -1).T
                centered = flat_label - self.pca_mean.to(flat_label.device)
                coeffs = torch.matmul(centered, self.pca_components.to(flat_label.device))
                pca_coeffs = coeffs.T.view(10, label_tensor.shape[1], label_tensor.shape[2])
                pca_coeffs_global = pca_coeffs.mean(dim=(1, 2))
                return input_tensor, target_band, pca_coeffs_global
            else:
                return input_tensor, target_band, torch.ones(10) * 1e-6

        return input_tensor, target_band

def create_single_band_loaders(target_band_idx, batch_size=16, num_workers=8, data_type='with_indices', use_3d=False, return_anchor=False):
    if data_type == 'with_indices':
        input_dir_name = "input_restacked_16_with_indices"
    elif data_type == 'repeated':
        input_dir_name = "input_restacked_16_repeated"
    elif data_type == 'raw':
        input_dir_name = "input"
    else:
        input_dir_name = "input_restacked_16"
    
    possible_base_dirs = []
    if BASE_DIR: possible_base_dirs.append(BASE_DIR)
    
    script_dir = os.path.dirname(os.path.abspath(__file__))
    project_root = os.path.dirname(script_dir)
    possible_base_dirs.append(os.path.join(project_root, "dataset"))
    
    input_dir = None
    label_dir = None
    
    for base_dir in possible_base_dirs:
        test_input_dir = os.path.join(base_dir, input_dir_name)
        test_label_dir = os.path.join(base_dir, "label")
        if os.path.exists(test_input_dir) and os.path.exists(test_label_dir):
            input_dir = test_input_dir
            label_dir = test_label_dir
            break
    
    if input_dir is None or label_dir is None:
        raise FileNotFoundError(f"未找到数据目录 {input_dir_name} 或 label。搜索路径: {possible_base_dirs}")
    
    full_dataset = SingleBandDataset(input_dir, label_dir, target_band_idx, use_3d=use_3d, return_anchor=return_anchor)
    
    dataset_size = len(full_dataset)
    train_size = int(0.7 * dataset_size)
    val_size = int(0.15 * dataset_size)
    test_size = dataset_size - train_size - val_size
    
    train_dataset, val_dataset, test_dataset = torch.utils.data.random_split(
        full_dataset, [train_size, val_size, test_size],
        generator=torch.Generator().manual_seed(42)
    )
    
    num_workers = 0 if os.name == 'nt' else 8
    train_loader = DataLoader(train_dataset, batch_size=batch_size, shuffle=True, num_workers=num_workers, drop_last=True)
    val_loader = DataLoader(val_dataset, batch_size=batch_size*2, shuffle=False, num_workers=num_workers)
    test_loader = DataLoader(test_dataset, batch_size=batch_size*2, shuffle=False, num_workers=num_workers)
    
    return train_loader, val_loader, test_loader

def get_spectral_similarity(band1, band2):
    """计算光谱相似性"""
    wavelength_groups = {
        'visible': (0, 79),
        'nir': (80, 159), 
        'swir': (160, 218)
    }
    
    def get_group(band):
        for group, (start, end) in wavelength_groups.items():
            if start <= band <= end:
                return group
        return 'unknown'
    
    group1 = get_group(band1)
    group2 = get_group(band2)
    
    distance = abs(band1 - band2)
    
    if group1 == group2:
        similarity = 1.0 / (1.0 + distance * 0.1)
    else:
        similarity = 1.0 / (1.0 + distance * 0.2)
    
    return similarity

def find_best_pretrained_model(target_band_idx, trained_bands, checkpoint_dir, current_strategy, use_pretrained=False, pretrained_strategy=None):
    """找到最佳预训练模型"""
    if not use_pretrained:
        print(f"🆕 波段 {target_band_idx} 从零开始训练（禁用预训练模型）")
        return None
        
    if not trained_bands:
        print(f"🆕 波段 {target_band_idx} 从零开始训练（无可用的预训练模型）")
        return None
    
    similarities = []
    for trained_band in trained_bands:
        similarity = get_spectral_similarity(target_band_idx, trained_band)
        similarities.append((trained_band, similarity))
    
    similarities.sort(key=lambda x: x[1], reverse=True)
    best_band = similarities[0][0]
    
    search_strategies = []
    if pretrained_strategy:
        search_strategies = [pretrained_strategy]
        print(f"🔍 在指定策略 {pretrained_strategy} 中查找预训练模型...")
    else:
        search_strategies = [current_strategy]
        try:
            all_strategies = [d for d in os.listdir(checkpoint_dir) 
                            if os.path.isdir(os.path.join(checkpoint_dir, d)) and d != current_strategy]
            search_strategies.extend(all_strategies)
        except:
            pass
        print(f"🔍 查找预训练模型顺序: {search_strategies}")
    
    for strategy in search_strategies:
        strategy_models_dir = os.path.join(checkpoint_dir, strategy, "models")
        best_model_path = os.path.join(strategy_models_dir, f"band_{best_band:03d}_best_model.pth")
        
        if os.path.exists(best_model_path):
            print(f"🔗 波段 {target_band_idx} 使用波段 {best_band} 的预训练模型")
            print(f"   相似性: {similarities[0][1]:.3f}")
            print(f"   来源策略: {strategy}")
            print(f"   模型路径: {best_model_path}")
            return best_model_path
    
    print(f"🆕 波段 {target_band_idx} 从零开始训练（未找到合适的预训练模型）")
    return None

def get_cascade_training_params(target_band_idx, pretrained_available, cascade_level):
    """获取训练参数"""
    base_epochs = 2
    base_lr = 2e-4
    
    if not pretrained_available:
        return {
            'epochs': base_epochs,
            'lr': base_lr,
            'weight_decay': 5e-6,
            'warmup_epochs': 1,
            'gradient_clip': 1.0,
            'accumulation_steps': 2
        }
    else:
        lr_decay = 0.7 ** cascade_level
        epoch_decay = max(0.5, 0.9 ** cascade_level)
        
        return {
            'epochs': max(40, int(base_epochs * epoch_decay)),
            'lr': base_lr * lr_decay,
            'weight_decay': 5e-6,
            'warmup_epochs': 5,
            'gradient_clip': 1.0,
            'accumulation_steps': 1
        }

def evaluate_model(model, test_loader, device, norm_params):
    """评估模型性能"""
    criterion = nn.MSELoss()
    test_loss = 0.0
    test_mse = 0.0
    test_mae = 0.0
    test_rmse_original = 0.0
    test_mae_original = 0.0
    num_samples = 0
    
    with torch.no_grad():
        for batch in test_loader:   # ←← 正确写法
            # 支持 (inputs, targets) 或 (inputs, targets, anchor_gt)
            if len(batch) == 3:
                inputs, targets, _ = batch
            else:
                inputs, targets = batch

            inputs = inputs.to(device)
            targets = targets.to(device)

            outputs = model(inputs)

            # 处理 use_anchor=True 返回 tuple 的情况
            if isinstance(outputs, tuple):
                outputs = outputs[0]

            test_loss += criterion(outputs, targets).item()
            test_mse += nn.MSELoss()(outputs, targets).item() * inputs.size(0)
            test_mae += nn.L1Loss()(outputs, targets).item() * inputs.size(0)
            
            if norm_params is not None:
                for b in range(outputs.shape[0]):
                    pred_denorm = denormalize_prediction(outputs[b, 0].cpu().numpy(), norm_params)
                    target_denorm = denormalize_prediction(targets[b, 0].cpu().numpy(), norm_params)
                    
                    rmse_orig = np.sqrt(np.mean((pred_denorm - target_denorm) ** 2))
                    mae_orig = np.mean(np.abs(pred_denorm - target_denorm))
                    
                    test_rmse_original += rmse_orig
                    test_mae_original += mae_orig
            
            num_samples += inputs.size(0)
    
    results = {
        'test_loss': test_loss / len(test_loader),
        'mse': test_mse / num_samples,
        'mae': test_mae / num_samples,
        'rmse': np.sqrt(test_mse / num_samples)
    }
    
    if norm_params is not None and num_samples > 0:
        results.update({
            'rmse_original': test_rmse_original / num_samples,
            'mae_original': test_mae_original / num_samples,
            'norm_range': [norm_params['p1'], norm_params['p99']]
        })
    
    return results


def load_custom_strategy_from_txt(txt_file):
    """从txt文件加载自定义策略"""
    strategy_data = {}
    strategy_name = "custom"
    
    with open(txt_file, 'r', encoding='utf-8') as f:
        lines = f.readlines()
    
    for line in lines:
        line = line.strip()
        if line.startswith('#') or not line:
            continue
        
        # 解析策略名称
        if line.startswith('strategy_name:'):
            strategy_name = line.split(':', 1)[1].strip()
        
        # 解析级别
        elif line.startswith('level_'):
            parts = line.split(':', 1)
            level = int(parts[0].split('_')[1])
            bands_str = parts[1].strip()
            # 解析波段列表 [1, 2, 3] 或 1,2,3
            if bands_str.startswith('[') and bands_str.endswith(']'):
                bands_str = bands_str[1:-1]
            bands = [int(x.strip()) for x in bands_str.split(',') if x.strip()]
            strategy_data[level] = bands
    
    return strategy_data, strategy_name

def design_cascade_strategy(strategy_type="physical", custom_txt_file=None):
    """设计级联策略"""
    print(f"🔍 [DEBUG] 进入design_cascade_strategy函数")
    print(f"🔍 [DEBUG] 参数: strategy_type='{strategy_type}', custom_txt_file={custom_txt_file}")
    
    try:
        print(f"🔍 开始解析策略类型: {strategy_type}")
        
        if strategy_type == "physical":
            print("✅ 使用内置physical策略")
            result = {
                0: [0, 1, 2, 3, 4, 5, 6, 7, 8],
                1: [15, 25, 27],
                2: [48, 50, 54, 67, 81, 83, 90],
                3: [108, 125, 135],
                4: [155, 162, 175, 185, 189, 210, 218]
            }
            print(f"🔍 [DEBUG] physical策略返回: {result}")
            return result
            
        elif strategy_type == "uniform":
            print("✅ 使用内置uniform策略")
            selected_bands = [int(i * 218 / 28) for i in range(29)]
            result = {
                0: selected_bands[0:9],
                1: selected_bands[9:12],
                2: selected_bands[12:19],
                3: selected_bands[19:22],
                4: selected_bands[22:29]
            }
            print(f"🔍 [DEBUG] uniform策略返回: {result}")
            return result
            
        elif strategy_type == "custom":
            print(f"🔍 [DEBUG] 处理custom策略")
            if custom_txt_file is None:
                raise ValueError("使用custom策略时需要提供custom_txt_file参数")
            print(f"📄 加载自定义策略文件: {custom_txt_file}")
            strategy_data, _ = load_custom_strategy_from_txt(custom_txt_file)
            print(f"🔍 [DEBUG] custom策略返回: {strategy_data}")
            return strategy_data
        else:
            print(f"🔍 [DEBUG] 处理txt文件策略: {strategy_type}")
            txt_based_strategies = ["variance_importance", "correlation_importance", "mutual_info_importance", "spectral_physics_importance"]
            
            if strategy_type not in txt_based_strategies:
                available_strategies = ['physical', 'uniform'] + txt_based_strategies + ['custom']
                error_msg = f"未知策略: {strategy_type}。可用策略: {available_strategies}"
                print(f"❌ [DEBUG] {error_msg}")
                raise ValueError(error_msg)
            
            print(f"🔍 从txt文件加载策略: {strategy_type}")
            
            possible_strategies_dirs = [
                "/home/ai4sg/tang/Swin-UNETR-Clean/checkpoints/importance_analysis/strategies",
                "D:/wisc/SpecTran/codes/Swin-Unetr/Swin-UNETR-Clean/checkpoints/importance_analysis/strategies",
                os.path.join(CHECKPOINT_DIR, "importance_analysis", "strategies"),
            ]
            
            strategies_dir = None
            for i, possible_dir in enumerate(possible_strategies_dirs):
                try:
                    if os.path.exists(possible_dir):
                        strategies_dir = possible_dir
                        print(f"✅ 找到strategies目录: {strategies_dir}")
                        break
                except Exception as e:
                    pass
            
            if strategies_dir is None:
                raise FileNotFoundError(f"未找到strategies目录。策略: {strategy_type}")
            
            strategy_file_mapping = {
                "variance_importance": "variance_strategy.txt",
                "correlation_importance": "correlation_strategy.txt", 
                "mutual_info_importance": "mutual_info_strategy.txt",
                "spectral_physics_importance": "spectral_physics_strategy.txt"
            }
            
            if strategy_type in strategy_file_mapping:
                strategy_file = os.path.join(strategies_dir, strategy_file_mapping[strategy_type])
                if os.path.exists(strategy_file):
                    strategy_data, _ = load_custom_strategy_from_txt(strategy_file)
                    return strategy_data
                else:
                    raise FileNotFoundError(f"策略文件不存在: {strategy_file}")
            else:
                raise ValueError(f"策略 {strategy_type} 不在txt加载列表中")
            
    except Exception as e:
        print(f"❌ [DEBUG] design_cascade_strategy函数出错: {e}")
        import traceback
        traceback.print_exc()
        raise

def get_all_trained_bands(checkpoint_dir, current_strategy, use_pretrained=False, pretrained_strategy=None):
    """获取可用的预训练波段"""
    trained_bands = []
    
    if not use_pretrained:
        print(f"🚫 禁用预训练模型，不扫描已训练波段")
        return trained_bands
    
    if not os.path.exists(checkpoint_dir):
        print(f"⚠️ 检查点目录不存在: {checkpoint_dir}")
        return trained_bands
    
    scan_strategies = []
    if pretrained_strategy:
        scan_strategies = [pretrained_strategy]
        print(f"🔍 只扫描指定策略: {pretrained_strategy}")
    else:
        try:
            scan_strategies = [d for d in os.listdir(checkpoint_dir) 
                             if os.path.isdir(os.path.join(checkpoint_dir, d))]
            print(f"🔍 扫描所有策略: {scan_strategies}")
        except Exception as e:
            print(f"⚠️ 扫描策略目录时出错: {e}")
            return trained_bands
    
    for strategy in scan_strategies:
        strategy_path = os.path.join(checkpoint_dir, strategy)
        models_dir = os.path.join(strategy_path, "models")
        
        if os.path.exists(models_dir):
            try:
                for f in os.listdir(models_dir):
                    if f.startswith('band_') and f.endswith('_best_model.pth'):
                        try:
                            band_num = int(f.split('_')[1])
                            trained_bands.append(band_num)
                        except ValueError:
                            continue
            except Exception as e:
                print(f"⚠️ 扫描策略 {strategy} 时出错: {e}")
    
    trained_bands = sorted(list(set(trained_bands)))
    
    if trained_bands:
        print(f"📊 发现可用预训练波段: {len(trained_bands)} 个")
        print(f"   波段列表: {trained_bands}")
    else:
        print(f"📊 未发现可用预训练波段")
    
    return trained_bands

def get_current_strategy_trained_bands(checkpoint_dir, strategy_name):
    """获取当前策略已训练的波段"""
    trained_bands = []
    
    strategy_path = os.path.join(checkpoint_dir, strategy_name)
    models_dir = os.path.join(strategy_path, "models")
    
    if os.path.exists(models_dir):
        try:
            for f in os.listdir(models_dir):
                if f.startswith('band_') and f.endswith('_best_model.pth'):
                    try:
                        band_num = int(f.split('_')[1])
                        trained_bands.append(band_num)
                    except ValueError:
                        continue
        except Exception as e:
            print(f"⚠️ 扫描当前策略模型时出错: {e}")
    
    trained_bands = sorted(list(set(trained_bands)))
    
    if trained_bands:
        print(f"📊 当前策略已训练波段: {len(trained_bands)} 个 {trained_bands}")
    else:
        print(f"📊 当前策略未发现已训练波段")
    
    return trained_bands

def save_cascade_record(cascade_levels, strategy_name, base_dir):
    """保存级联记录到统一的txt文件"""
    record_file = os.path.join(base_dir, "cascade_levels.txt")
    mode = 'a' if os.path.exists(record_file) else 'w'
    
    with open(record_file, mode, encoding='utf-8') as f:
        if mode == 'w':
            f.write("# 级联训练波段级别记录\n")
            f.write(f"# 生成时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
            f.write("# 格式: Band_xxx -> Level_x (Strategy: strategy_name)\n")
            f.write("=" * 70 + "\n\n")
        
        f.write(f"# {strategy_name.upper()} 策略:\n")
        f.write(f"# 总级别数: {len(cascade_levels)}\n")
        f.write(f"# 总波段数: {sum(len(bands) for bands in cascade_levels.values())}\n")
        f.write("-" * 50 + "\n")
        
        for level in sorted(cascade_levels.keys()):
            bands = cascade_levels[level]
            for band in sorted(bands):
                f.write(f"Band_{band:03d} -> Level_{level} (Strategy: {strategy_name})\n")
        
        f.write("\n" + "=" * 70 + "\n\n")
    
    print(f"📝 级联记录已追加到: {record_file}")
    return record_file

def save_training_summary(strategy_name, base_dir, cascade_levels, training_results):
    """保存训练总结到策略专用目录"""
    strategy_dir = os.path.join(base_dir, strategy_name)
    os.makedirs(strategy_dir, exist_ok=True)
    
    summary_file = os.path.join(strategy_dir, "training_summary.json")
    
    summary = {
        'strategy': strategy_name,
        'timestamp': datetime.now().isoformat(),
        'cascade_levels': cascade_levels,
        'total_bands': sum(len(bands) for bands in cascade_levels.values()),
        'total_levels': len(cascade_levels),
        'training_results': training_results,
        'best_bands': {
            'lowest_rmse': min(training_results.items(), key=lambda x: x[1].get('rmse', float('inf')))[0] if training_results else None,
            'lowest_mae': min(training_results.items(), key=lambda x: x[1].get('mae', float('inf')))[0] if training_results else None
        }
    }
    
    with open(summary_file, 'w', encoding='utf-8') as f:
        json.dump(summary, f, indent=2, ensure_ascii=False)
    
    print(f"📊 训练总结已保存到: {summary_file}")
    return summary_file

def train_single_band_model(target_band_idx, cascade_level, batch_size, device, 
                           pretrained_model_path, strategy_dir, writer, data_type='with_indices', use_3d=False, use_anchor=False):
    
    print(f"\n🎯 训练 Band {target_band_idx} (Level {cascade_level}) - {'3D' if use_3d else '2D'} 模式 - Anchor: {use_anchor}")
    if device.type == 'cuda': torch.cuda.empty_cache()
    
    train_loader, val_loader, test_loader = create_single_band_loaders(target_band_idx, batch_size, data_type=data_type, use_3d=use_3d, return_anchor=use_anchor)
    train_params = get_cascade_training_params(target_band_idx, pretrained_model_path is not None, cascade_level)
    
    if use_3d:
        depth = 32 
        if data_type == 'raw':
            patch_size = (2, 2, 2) 
            downsample = "merging" 
            print(f"ℹ️ 使用手动构造的 32-Depth 序列 (6-7-6-7-6 Mix) + 标准 SwinUNETR")
        else:
            patch_size = 2 
            downsample = "merging"
            
        model = SwinUNETR_SingleBand(
            in_channels=1, img_size=(depth, 128, 128), spatial_dims=3,
            use_anchor=use_anchor, patch_size=patch_size, downsample=downsample
        ).to(device)
    else:
        in_channels = 5 if data_type == 'raw' else 16
        model = SwinUNETR_SingleBand(
            in_channels=in_channels, img_size=(128, 128), spatial_dims=2,
            use_anchor=use_anchor, patch_size=2, downsample="mergingv2"
        ).to(device)
    
    if pretrained_model_path and os.path.exists(pretrained_model_path):
        try:
            checkpoint = torch.load(pretrained_model_path, map_location=device)
            model.load_state_dict(checkpoint['model_state_dict'])
            print("✅ 预训练权重加载成功")
        except Exception as e:
            print(f"⚠️ 预训练权重加载失败: {e}")
    
    criterion = nn.MSELoss()
    anchor_mse_criterion = nn.MSELoss() if use_anchor else None
    anchor_sam_criterion = SAMLoss(spectral_dim=1) if use_anchor else None
    
    optimizer = optim.AdamW(model.parameters(), lr=train_params['lr'], weight_decay=train_params['weight_decay'])
    scaler = torch.cuda.amp.GradScaler() if device.type == 'cuda' else None
    
    warmup_scheduler = optim.lr_scheduler.LinearLR(optimizer, start_factor=0.05, total_iters=train_params['warmup_epochs'])
    main_scheduler = optim.lr_scheduler.OneCycleLR(optimizer, max_lr=train_params['lr'] * 2, total_steps=train_params['epochs'] - train_params['warmup_epochs'], pct_start=0.3, anneal_strategy='cos')
    
    best_val_loss = float('inf')
    best_model_path = os.path.join(strategy_dir, f"band_{target_band_idx:03d}_best_model.pth")
    
    for epoch in range(1, train_params['epochs'] + 1):
        model.train()
        train_loss = 0.0
        pbar = tqdm(train_loader, desc=f"🔥 Band {target_band_idx} L{cascade_level} Epoch {epoch}")
        
        for batch_idx, batch_data in enumerate(pbar):
            if use_anchor:
                inputs, targets, anchor_gt = batch_data
                anchor_gt = anchor_gt.to(device, non_blocking=True)
            else:
                inputs, targets = batch_data
            
            inputs, targets = inputs.to(device, non_blocking=True), targets.to(device, non_blocking=True)
            
            with torch.cuda.amp.autocast() if scaler else contextlib.nullcontext():
                if use_anchor:
                    outputs, anchor_pred = model(inputs)
                    main_loss = criterion(outputs, targets)
                    a_loss = 0.1 * anchor_mse_criterion(anchor_pred, anchor_gt) + 0.1 * anchor_sam_criterion(anchor_pred, anchor_gt)
                    loss = main_loss + a_loss
                else:
                    outputs = model(inputs)
                    loss = criterion(outputs, targets)
                
                if 'accumulation_steps' in train_params:
                    loss = loss / train_params['accumulation_steps']
            
            if scaler:
                scaler.scale(loss).backward()
                if (batch_idx + 1) % train_params.get('accumulation_steps', 1) == 0:
                    scaler.step(optimizer)
                    scaler.update()
                    optimizer.zero_grad()
            else:
                loss.backward()
                if (batch_idx + 1) % train_params.get('accumulation_steps', 1) == 0:
                    optimizer.step()
                    optimizer.zero_grad()
            
            train_loss += loss.item() * train_params.get('accumulation_steps', 1)
            pbar.set_postfix({'Loss': f'{loss.item():.6f}'})
        
        avg_train_loss = train_loss / len(train_loader)
        
        model.eval()
        val_loss = 0.0
        with torch.no_grad():
            for batch_data in val_loader:
                if use_anchor:
                    inputs, targets, anchor_gt = batch_data
                    anchor_gt = anchor_gt.to(device)
                else:
                    inputs, targets = batch_data
                inputs, targets = inputs.to(device), targets.to(device)
                
                if use_anchor:
                    outputs, anchor_pred = model(inputs)
                    loss = criterion(outputs, targets) + 0.1 * anchor_mse_criterion(anchor_pred, anchor_gt) + 0.1 * anchor_sam_criterion(anchor_pred, anchor_gt)
                else:
                    outputs = model(inputs)
                    loss = criterion(outputs, targets)
                val_loss += loss.item()
        
        avg_val_loss = val_loss / len(val_loader)
        
        if epoch <= train_params['warmup_epochs']: warmup_scheduler.step()
        else: main_scheduler.step()
        
        writer.add_scalar(f'Loss/Train_Band_{target_band_idx}', avg_train_loss, cascade_level * 1000 + epoch)
        writer.add_scalar(f'Loss/Val_Band_{target_band_idx}', avg_val_loss, cascade_level * 1000 + epoch)
        
        if avg_val_loss < best_val_loss:
            best_val_loss = avg_val_loss
            torch.save({'model_state_dict': model.state_dict()}, best_model_path)
    
    # Final Test
    if os.path.exists(best_model_path):
        model.load_state_dict(torch.load(best_model_path, map_location=device)['model_state_dict'])
    
    dataset = train_loader.dataset
    norm_params = dataset.dataset.get_norm_params() if hasattr(dataset, 'dataset') else dataset.get_norm_params()
    test_results = evaluate_model(model, test_loader, device, norm_params)
    return best_model_path, test_results

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--strategy', type=str, default='physical')
    parser.add_argument('--custom_txt', type=str, default=None)
    parser.add_argument('--batch_size', type=int, default=1)
    parser.add_argument('--device', type=str, default='cuda')
    parser.add_argument('--start_level', type=int, default=0)
    parser.add_argument('--end_level', type=int, default=4)
    parser.add_argument('--data_type', type=str, default='with_indices')
    parser.add_argument('--use_pretrained', action='store_true', default=False)
    parser.add_argument('--pretrained_strategy', type=str, default=None)
    parser.add_argument('--force_retrain', action='store_true', default=False)
    parser.add_argument('--use_anchor', action='store_true', default=False)
    parser.add_argument('--use_3d', action='store_true', default=False)
    
    args = parser.parse_args()
    
    try:
        if args.strategy == "custom":
            if not args.custom_txt: raise ValueError("Need --custom_txt")
            cascade_levels = design_cascade_strategy(args.strategy, args.custom_txt)
            _, strategy_name = load_custom_strategy_from_txt(args.custom_txt)
        else:
            cascade_levels = design_cascade_strategy(args.strategy)
            strategy_name = args.strategy
    except Exception as e:
        print(f"❌ 策略加载失败: {e}")
        return

    if args.data_type == 'raw':
        strategy_name_with_suffix = f"{strategy_name}_raw"
    else:
        strategy_name_with_suffix = f"{strategy_name}_{args.data_type}"
        
    strategy_dir = os.path.join(CHECKPOINT_DIR, strategy_name_with_suffix)
    os.makedirs(strategy_dir, exist_ok=True)
    models_dir = os.path.join(strategy_dir, "models")
    os.makedirs(models_dir, exist_ok=True)
    tensorboard_dir = os.path.join(strategy_dir, "tensorboard_logs")
    writer = SummaryWriter(tensorboard_dir)
    
    try:
        save_cascade_record(cascade_levels, strategy_name, strategy_dir)
    except Exception as e:
        print(f"⚠️ 保存记录失败: {e}")

    device = torch.device(args.device if torch.cuda.is_available() else 'cpu')
    
    available_pretrained_bands = get_all_trained_bands(CHECKPOINT_DIR, strategy_name_with_suffix, args.use_pretrained, args.pretrained_strategy)
    current_strategy_bands = get_current_strategy_trained_bands(CHECKPOINT_DIR, strategy_name_with_suffix)
    training_results = {}
    
    try:
        for level in range(args.start_level, args.end_level + 1):
            if level not in cascade_levels: continue
            bands_to_train = cascade_levels[level]
            
            for band_idx in bands_to_train:
                try:
                    if not args.force_retrain and band_idx in current_strategy_bands:
                        print(f"⏭️ 跳过波段 {band_idx}")
                        continue
                    
                    pretrained_path = find_best_pretrained_model(band_idx, available_pretrained_bands, CHECKPOINT_DIR, strategy_name_with_suffix, args.use_pretrained, args.pretrained_strategy)
                    
                    _, results = train_single_band_model(
                        target_band_idx=band_idx,
                        cascade_level=level,
                        batch_size=args.batch_size,
                        device=device,
                        pretrained_model_path=pretrained_path,
                        strategy_dir=models_dir,
                        writer=writer,
                        data_type=args.data_type,
                        use_3d=args.use_3d,
                        use_anchor=args.use_anchor
                    )
                    training_results[f"band_{band_idx:03d}"] = results
                    current_strategy_bands.append(band_idx)
                    
                except Exception as e:
                    print(f"❌ 波段 {band_idx} 训练失败: {e}")
                    import traceback
                    traceback.print_exc()
                    continue
        
        save_training_summary(strategy_name_with_suffix, CHECKPOINT_DIR, cascade_levels, training_results)
    except Exception as e:
        print(f"❌ 训练过程出错: {e}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    main()
