﻿import torch
import numpy as np

def denormalize_prediction(normalized_pred, norm_params):
    """
    反归一化预测结果
    Args:
        normalized_pred: [0,1]范围的预测值
        norm_params: 包含p1和p99的字典
    Returns:
        原始范围的预测值
    """
    p1, p99 = norm_params['p1'], norm_params['p99']
    original = normalized_pred * (p99 - p1) + p1
    return original

def denormalize_batch(normalized_batch, norm_params_list):
    """
    批量反归一化
    Args:
        normalized_batch: [B, C, H, W] 归一化张量
        norm_params_list: 每个波段的归一化参数列表
    Returns:
        反归一化后的张量
    """
    if isinstance(normalized_batch, torch.Tensor):
        normalized_batch = normalized_batch.cpu().numpy()
    
    denormalized = np.zeros_like(normalized_batch)
    
    for b in range(normalized_batch.shape[0]):
        for c in range(normalized_batch.shape[1]):
            if c < len(norm_params_list):
                denormalized[b, c] = denormalize_prediction(
                    normalized_batch[b, c], 
                    norm_params_list[c]
                )
    
    return torch.tensor(denormalized)
