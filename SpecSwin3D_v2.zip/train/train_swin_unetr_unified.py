import sys
import os
import json
import contextlib
from datetime import datetime
import glob
from tqdm import tqdm
import argparse
import numpy as np

# ========= 路径 & 配置 =========
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from config import BASE_DIR, CHECKPOINT_DIR

project_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

# 🔥 适配 Colab/Linux 与 Windows 的路径
if os.name == 'posix':  # Linux / Colab
    print(f"🐧 检测到 Linux/Colab 环境，强制使用相对路径")
    CHECKPOINT_DIR = os.path.join(project_root, "checkpoints")
    BASE_DIR = os.path.join(project_root, "dataset")
    print(f"   ➡️ 新 CHECKPOINT_DIR: {CHECKPOINT_DIR}")
    print(f"   ➡️ 新 BASE_DIR: {BASE_DIR}")
elif os.name == 'nt':   # Windows
    drive, _ = os.path.splitdrive(CHECKPOINT_DIR)
    if drive and not os.path.exists(drive):
        print(f"⚠️ 检测到配置的驱动器 {drive} 不存在，切换到相对路径模式")
        CHECKPOINT_DIR = os.path.join(project_root, "checkpoints")
        BASE_DIR = os.path.join(project_root, "dataset")
        print(f"   ➡️ 新 CHECKPOINT_DIR: {CHECKPOINT_DIR}")
        print(f"   ➡️ 新 BASE_DIR: {BASE_DIR}")

import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import Dataset, DataLoader
from torch.utils.tensorboard import SummaryWriter

# 工具 & 损失
from denormalize_utils import denormalize_prediction
from losses import SAMLoss, SpectralSmoothnessLoss

# 模型
from models.swin_unetr_local import SwinUNETR_Local as SwinUNETR


# ========= Learned Channel Positional Encoding =========
class LearnedChannelPE(nn.Module):
    """
    对输入的每个通道（channel）学习一个位置编码：
    x: [B, C, H, W]
    pe: [1, C, 1, 1]，训练后代表“该通道在光谱轴上的身份/偏置”
    """
    def __init__(self, num_channels: int):
        super().__init__()
        self.pe = nn.Parameter(torch.zeros(1, num_channels, 1, 1))

    def forward(self, x):
        return x + self.pe


# ========= 数据集：5-band 输入 → 6-7-6-7-6 → 32 通道 → 219 HS =========
class UnifiedHSDataset_5to219(Dataset):
    """
    统一光谱重建数据集：
    磁盘输入：5 通道 MS（shape: [5, H, W]）
    数据加载时：
        利用 6-7-6-7-6 hand-crafted 组合，将 5 通道展开为 32 通道：
            - 每个 slice 是若干 band 的均值
        得到输入：X ∈ R^{32×H×W}
    输出：219 个 HS 波段 label（不包含 5 个原始 MS 波段）
    可选：PCA Anchor 作为全局光谱形状监督
    """
    def __init__(self, input_dir, label_dir, return_anchor=False):
        self.input_dir = input_dir
        self.label_dir = label_dir
        self.return_anchor = return_anchor

        # 加载 PCA 统计（用于 Anchor）
        self.pca_components = None
        self.pca_mean = None
        if self.return_anchor:
            possible_pca_paths = [
                os.path.join(BASE_DIR, 'pca_stats.pt'),
                os.path.join(os.path.dirname(BASE_DIR), 'pca_stats.pt'),
                os.path.join(project_root, 'dataset', 'pca_stats.pt')
            ]
            pca_path = None
            for path in possible_pca_paths:
                if os.path.exists(path):
                    pca_path = path
                    break
            if pca_path:
                pca_stats = torch.load(pca_path, map_location='cpu')
                self.pca_components = pca_stats['components'].float()  # (219, K) 或 (224, K)
                self.pca_mean = pca_stats['mean'].float()              # (219,) 或 (224,)
                print(f"✅ 已加载 PCA 统计数据: {pca_path}")
            else:
                print(f"⚠️ 未找到 PCA 统计数据，将不使用 Anchor 监督")
                self.return_anchor = False

        # 输入 & 标签文件列表
        self.input_files = sorted(glob.glob(os.path.join(input_dir, "*.pt")))
        self.label_files = sorted(glob.glob(os.path.join(label_dir, "*.pt")))
        assert len(self.input_files) == len(self.label_files), \
            f"输入文件数({len(self.input_files)})与标签文件数({len(self.label_files)})不匹配"

        print(f"📊 Unified 5→219 数据集: {len(self.input_files)} 样本")

        # 读取归一化参数（每个 band 一组）
        sample_label = torch.load(self.label_files[0], map_location='cpu')
        self.norm_params_list = None
        self.label_band_indices = None
        if isinstance(sample_label, dict) and 'norm_params' in sample_label:
            self.label_band_indices = sample_label.get('band_indices', None)
            self.norm_params_list = sample_label['norm_params']
        else:
            print("⚠️ 标签中未找到 norm_params，将仅计算归一化空间的误差")

        # 准备 6-7-6-7-6 的组合索引
        self.depth_indices = self._generate_6_7_6_7_6_indices()

    def _generate_6_7_6_7_6_indices(self):
        import itertools

        indices = [0, 1, 2, 3, 4]
        pool_L1 = list(itertools.combinations(indices, 1))   # C(5,1) = 5
        pool_L2 = list(itertools.combinations(indices, 2))   # C(5,2) = 10
        pool_L3 = list(itertools.combinations(indices, 3))   # C(5,3) = 10
        pool_L4 = list(itertools.combinations(indices, 4))   # C(5,4) = 5
        pool_L5 = list(itertools.combinations(indices, 5)) * 2  # C(5,5)=1，乘2保证够用

        def make_block_A():
            return [
                pool_L1.pop(0),
                pool_L2.pop(0),
                pool_L3.pop(0),
                pool_L4.pop(0),
                pool_L2.pop(0),
                pool_L3.pop(0),
            ]

        def make_block_B():
            return [
                pool_L1.pop(0),
                pool_L2.pop(0),
                pool_L3.pop(0),
                pool_L5.pop(0),
                pool_L4.pop(0),
                pool_L2.pop(0),
                pool_L3.pop(0),
            ]

        final_sequence = []
        final_sequence.extend(make_block_A())  # 6
        final_sequence.extend(make_block_B())  # 7
        final_sequence.extend(make_block_A())  # 6
        final_sequence.extend(make_block_B())  # 7
        final_sequence.extend(make_block_A())  # 6

        assert len(final_sequence) == 32, f"6-7-6-7-6 组合总数应为 32，实际 {len(final_sequence)}"

        final_sequence = [list(tup) for tup in final_sequence]
        print(f"✅ 6-7-6-7-6 hand-crafted 组合生成完毕，共 {len(final_sequence)} 个 slices")
        return final_sequence

    def __len__(self):
        return len(self.input_files)

    def get_norm_params_list(self):
        return self.norm_params_list, self.label_band_indices

    def __getitem__(self, idx):
        input_data = torch.load(self.input_files[idx], map_location='cpu')
        label_data = torch.load(self.label_files[idx], map_location='cpu')

        # input_tensor: [5, H, W]
        input_tensor = input_data['input'] if isinstance(input_data, dict) else input_data
        # label_tensor: [219, H, W]
        label_tensor = label_data['label'] if isinstance(label_data, dict) else label_data

        input_tensor = input_tensor.float()
        label_tensor = label_tensor.float()

        assert input_tensor.dim() == 3, f"期望 input 为 [5,H,W]，实际维度: {input_tensor.shape}"
        assert input_tensor.shape[0] == 5, f"期望 input 第0维为5个band，实际: {input_tensor.shape[0]}"

        # 6-7-6-7-6 展开为 32 通道
        channels_32 = []
        for band_indices in self.depth_indices:
            selected = input_tensor[band_indices, :, :]  # [k, H, W]
            mean_band = selected.mean(dim=0, keepdim=True)  # [1, H, W]
            channels_32.append(mean_band)
        input_32 = torch.cat(channels_32, dim=0)  # [32, H, W]

        if self.return_anchor and (self.pca_components is not None):
            flat_label = label_tensor.view(label_tensor.shape[0], -1).t()   # [N, D]
            centered = flat_label - self.pca_mean.to(flat_label.device)     # [N, D]
            coeffs = torch.matmul(centered, self.pca_components.to(flat_label.device))  # [N, K]
            pca_coeffs_global = coeffs.mean(dim=0)  # [K]
            return input_32, label_tensor, pca_coeffs_global

        return input_32, label_tensor


def create_unified_loaders_5to219(batch_size=4, num_workers=8, return_anchor=False):
    input_dir_name = "input"
    possible_base_dirs = []
    if BASE_DIR:
        possible_base_dirs.append(BASE_DIR)

    script_dir = os.path.dirname(os.path.abspath(__file__))
    project_root = os.path.dirname(script_dir)
    possible_base_dirs.append(os.path.join(project_root, "dataset"))

    input_dir = None
    label_dir = None
    for base_dir in possible_base_dirs:
        test_input_dir = os.path.join(base_dir, input_dir_name)
        test_label_dir = os.path.join(base_dir, "label")
        if os.path.exists(test_input_dir) and os.path.exists(test_label_dir):
            input_dir = test_input_dir
            label_dir = test_label_dir
            break

    if input_dir is None or label_dir is None:
        raise FileNotFoundError(f"未找到数据目录 {input_dir_name} 或 label。搜索路径: {possible_base_dirs}")

    full_dataset = UnifiedHSDataset_5to219(input_dir, label_dir, return_anchor=return_anchor)
    dataset_size = len(full_dataset)
    train_size = int(0.7 * dataset_size)
    val_size = int(0.15 * dataset_size)
    test_size = dataset_size - train_size - val_size

    train_dataset, val_dataset, test_dataset = torch.utils.data.random_split(
        full_dataset, [train_size, val_size, test_size],
        generator=torch.Generator().manual_seed(42)
    )

    num_workers = 0 if os.name == 'nt' else num_workers
    train_loader = DataLoader(train_dataset, batch_size=batch_size, shuffle=True,
                              num_workers=num_workers, drop_last=True)
    val_loader = DataLoader(val_dataset, batch_size=batch_size * 2, shuffle=False,
                            num_workers=num_workers)
    test_loader = DataLoader(test_dataset, batch_size=batch_size * 2, shuffle=False,
                             num_workers=num_workers)

    return train_loader, val_loader, test_loader, full_dataset


# ========= 模型封装：统一 5→219 + 6-7-6-7-6 + Learned PE =========
class SwinUNETR_Unified_5to219(nn.Module):
    """
    统一光谱重建模型：
    输入：
        - 2D 模式： [B, 32, H, W]
        - 3D 模式： [B, 32, H, W] （内部转成 [B,1,32,H,W]）
    输出： [B, 219, H, W]
    """
    def __init__(self,
                 in_channels=32,
                 out_channels=219,
                 img_size=(128, 128),
                 spatial_dims=2,
                 use_anchor=False,
                 use_learned_pe=False,
                 patch_size=2,
                 downsample="mergingv2"):
        super().__init__()
        self.use_anchor = use_anchor
        self.use_learned_pe = use_learned_pe
        self.spatial_dims = spatial_dims

        if self.use_learned_pe:
            self.channel_pe = LearnedChannelPE(num_channels=in_channels)
        else:
            self.channel_pe = None

        if self.spatial_dims == 3:
            swin_in_channels = 1
            swin_img_size = (32, img_size[0], img_size[1])
            swin_patch_size = (2, 2, 2)
        else:
            swin_in_channels = in_channels
            swin_img_size = img_size
            swin_patch_size = patch_size

        self.model = SwinUNETR(
            img_size=swin_img_size,
            in_channels=swin_in_channels,
            out_channels=out_channels,
            feature_size=48,
            spatial_dims=self.spatial_dims,
            use_checkpoint=False,
            use_anchor_head=use_anchor,
            anchor_k=10,
            patch_size=swin_patch_size,
            downsample=downsample
        )

    def forward(self, x):
        if self.channel_pe is not None:
            x = self.channel_pe(x)   # 仍然是 [B,32,H,W]

        if self.spatial_dims == 2:
            if self.use_anchor:
                logits, anchor_out = self.model(x)
                return logits, anchor_out
            else:
                logits = self.model(x)
                return logits
        else:
            # 3D：把 32 当作 depth
            x_3d = x.unsqueeze(1)  # [B,1,32,H,W]
            if self.use_anchor:
                logits_3d, anchor_out = self.model(x_3d)   # [B,219,32,H,W]
            else:
                logits_3d = self.model(x_3d)
            logits = logits_3d.mean(dim=2)                # [B,219,H,W]
            if self.use_anchor:
                return logits, anchor_out
            else:
                return logits


# ========= 评估 =========
def evaluate_unified_model(model, test_loader, device, norm_params_list=None, band_indices=None):
    criterion_mse = nn.MSELoss()
    criterion_mae = nn.L1Loss()

    total_mse = 0.0
    total_mae = 0.0
    n_batches = 0

    use_denorm = (norm_params_list is not None) and (band_indices is not None)
    total_rmse_orig = 0.0
    total_mae_orig = 0.0
    n_pixels_batches = 0

    model.eval()
    with torch.no_grad():
        for batch in test_loader:
            if len(batch) == 3:
                inputs, targets, _ = batch
            else:
                inputs, targets = batch

            inputs = inputs.to(device)
            targets = targets.to(device)  # [B, 219, H, W]

            outputs = model(inputs)
            if isinstance(outputs, tuple):
                outputs = outputs[0]

            mse = criterion_mse(outputs, targets)
            mae = criterion_mae(outputs, targets)
            total_mse += mse.item()
            total_mae += mae.item()
            n_batches += 1

            if use_denorm:
                outputs_np = outputs.detach().cpu().numpy()
                targets_np = targets.detach().cpu().numpy()

                B, C, H, W = outputs_np.shape
                diff_sq_sum = 0.0
                diff_abs_sum = 0.0
                pixel_count = 0

                for b_idx in range(C):
                    norm_params = norm_params_list[b_idx]
                    pred_band = outputs_np[:, b_idx, :, :].reshape(-1)
                    gt_band = targets_np[:, b_idx, :, :].reshape(-1)

                    pred_denorm = denormalize_prediction(pred_band, norm_params)
                    gt_denorm = denormalize_prediction(gt_band, norm_params)

                    diff = pred_denorm - gt_denorm
                    diff_sq_sum += np.sum(diff ** 2)
                    diff_abs_sum += np.sum(np.abs(diff))
                    pixel_count += diff.shape[0]

                rmse_orig = np.sqrt(diff_sq_sum / pixel_count)
                mae_orig = diff_abs_sum / pixel_count

                total_rmse_orig += rmse_orig
                total_mae_orig += mae_orig
                n_pixels_batches += 1

    results = {
        'mse_norm': total_mse / max(1, n_batches),
        'mae_norm': total_mae / max(1, n_batches),
        'rmse_norm': np.sqrt(total_mse / max(1, n_batches))
    }
    if use_denorm and n_pixels_batches > 0:
        results['rmse_original'] = total_rmse_orig / n_pixels_batches
        results['mae_original']  = total_mae_orig / n_pixels_batches

    return results


# ========= 构建 cascade curriculum（按光谱距离） =========
def build_cascade_stages(label_band_indices, num_stages, ms_bands=None):
    """
    label_band_indices: 长度 219 的 list，存的是原始 HS band index（0~223 去掉 5个 MS）
    num_stages: 分几阶段
    ms_bands: 5个 MS band 的原始索引，例如 [9,20,30,40,52]
    返回：
        stages: list[list[int]]，每个 stage 里是 label 通道的索引（0~C-1）
        ordering_info: list of (channel_idx, hs_band_id, distance)
    """
    if label_band_indices is None:
        C = 219
        label_band_indices = list(range(C))
    else:
        C = len(label_band_indices)

    if ms_bands is None:
        ms_bands = [9, 20, 30, 40, 52]

    ordering_info = []
    for c, band_id in enumerate(label_band_indices):
        d = min(abs(band_id - m) for m in ms_bands)
        ordering_info.append((c, band_id, d))

    # 按距离从小到大排序
    ordering_info.sort(key=lambda x: x[2])
    ordered_channels = [x[0] for x in ordering_info]

    stages = []
    for s in range(1, num_stages + 1):
        k = int(round(C * s / num_stages))
        k = min(max(k, 1), C)
        stage_channels = ordered_channels[:k]
        stages.append(stage_channels)

    print("📚 Cascade curriculum stages (by spectral distance):")
    for i, st in enumerate(stages):
        max_d = max(ordering_info[c][2] for c in range(len(ordering_info)) if ordering_info[c][0] in st)
        print(f"  Stage {i+1}: {len(st)} bands supervised, up to distance ~{max_d}")

    return stages, ordering_info


# ========= 训练主循环 =========
def train_unified_model_5to219(
    batch_size,
    device,
    strategy_name,
    use_anchor=True,
    use_learned_pe=False,
    use_3d=False,
    use_cascade=False,
    num_stages=4,
    num_epochs=120,
    lr=2e-4,
    weight_decay=5e-6
):
    print(f"\n🎯 统一训练 5→219 模型（6-7-6-7-6 → 32ch）"
          f" - Anchor: {use_anchor} - LearnedPE: {use_learned_pe} - Use3D: {use_3d} - Cascade: {use_cascade}")

    # DataLoader
    train_loader, val_loader, test_loader, full_dataset = create_unified_loaders_5to219(
        batch_size=batch_size,
        num_workers=8,
        return_anchor=use_anchor
    )

    # 命名
    strategy_name_with_suffix = f"{strategy_name}_5to219_6_7_6_7_6"
    if use_learned_pe:
        strategy_name_with_suffix += "_pe"
    if use_3d:
        strategy_name_with_suffix += "_3d"
    if use_cascade:
        strategy_name_with_suffix += f"_cascade{num_stages}"

    strategy_dir = os.path.join(CHECKPOINT_DIR, strategy_name_with_suffix)
    os.makedirs(strategy_dir, exist_ok=True)
    models_dir = os.path.join(strategy_dir, "models")
    os.makedirs(models_dir, exist_ok=True)
    tensorboard_dir = os.path.join(strategy_dir, "tensorboard_logs")
    writer = SummaryWriter(tensorboard_dir)

    # 模型
    in_channels = 32
    out_channels = 219
    spatial_dims = 3 if use_3d else 2
    img_size = (128, 128)

    model = SwinUNETR_Unified_5to219(
        in_channels=in_channels,
        out_channels=out_channels,
        img_size=img_size,
        spatial_dims=spatial_dims,
        use_anchor=use_anchor,
        use_learned_pe=use_learned_pe,
        patch_size=2,
        downsample="mergingv2"
    ).to(device)

    # 损失
    recon_criterion = nn.L1Loss()
    sam_criterion   = SAMLoss(spectral_dim=1)
    smooth_criterion = SpectralSmoothnessLoss(p=1, spectral_dim=1)

    alpha_sam = 0.1
    beta_smooth = 0.01

    anchor_mse_criterion = nn.MSELoss() if use_anchor else None
    anchor_sam_criterion = SAMLoss(spectral_dim=1) if use_anchor else None

    optimizer = optim.AdamW(model.parameters(), lr=lr, weight_decay=weight_decay)
    scaler = torch.cuda.amp.GradScaler() if device.type == 'cuda' else None

    warmup_epochs = 10
    total_epochs = num_epochs

    warmup_scheduler = optim.lr_scheduler.LinearLR(
        optimizer, start_factor=0.05, total_iters=warmup_epochs
    )
    main_scheduler = optim.lr_scheduler.OneCycleLR(
        optimizer,
        max_lr=lr * 2,
        total_steps=max(1, total_epochs - warmup_epochs),
        pct_start=0.3,
        anneal_strategy='cos'
    )

    best_model_path = os.path.join(models_dir, "unified_best_model.pth")

    # ========= 构建 cascade 阶段 =========
    norm_params_list, label_band_indices = full_dataset.get_norm_params_list()
    if use_cascade:
        stages, ordering_info = build_cascade_stages(label_band_indices, num_stages)
        # 按 stage 平分 epochs
        base_stage_epochs = total_epochs // num_stages
        stage_epochs_list = [base_stage_epochs] * num_stages
        stage_epochs_list[-1] += total_epochs - base_stage_epochs * num_stages
    else:
        stages = [list(range(out_channels))]
        stage_epochs_list = [total_epochs]

    global_step = 0
    last_stage_best_path = None

    # ========= 按 stage 训练 =========
    for stage_idx, active_channels in enumerate(stages):
        stage_id = stage_idx + 1
        stage_epochs = stage_epochs_list[stage_idx]
        print(f"\n📚 Stage {stage_id}/{len(stages)}: supervise {len(active_channels)} / {out_channels} bands,"
              f" epochs = {stage_epochs}")

        # 每个 stage 单独 best
        best_val_loss = float('inf')
        stage_best_path = os.path.join(models_dir, f"unified_best_stage{stage_id}.pth")

        for epoch in range(1, stage_epochs + 1):
            model.train()
            train_loss = 0.0

            pbar = tqdm(train_loader, desc=f"🔥 Stage {stage_id} Epoch {epoch}/{stage_epochs}")
            for batch_idx, batch in enumerate(pbar):
                if use_anchor:
                    inputs, targets, anchor_gt = batch
                    anchor_gt = anchor_gt.to(device, non_blocking=True)
                else:
                    inputs, targets = batch

                inputs = inputs.to(device, non_blocking=True)
                targets = targets.to(device, non_blocking=True)  # [B,219,H,W]

                # 只对 active_channels 的通道计算重建 & SAM & Smooth
                with torch.cuda.amp.autocast() if scaler else contextlib.nullcontext():
                    if use_anchor:
                        outputs, anchor_pred = model(inputs)
                    else:
                        outputs = model(inputs)

                    outputs_stage = outputs[:, active_channels, :, :]
                    targets_stage = targets[:, active_channels, :, :]

                    main_loss = recon_criterion(outputs_stage, targets_stage)
                    sam_loss = sam_criterion(outputs_stage, targets_stage)
                    smooth_loss = smooth_criterion(outputs_stage)

                    loss = main_loss + alpha_sam * sam_loss + beta_smooth * smooth_loss

                    if use_anchor:
                        if anchor_gt.dim() == 1:
                            anchor_gt_batch = anchor_gt.unsqueeze(0).repeat(outputs.shape[0], 1)
                        else:
                            anchor_gt_batch = anchor_gt
                        a_mse = anchor_mse_criterion(anchor_pred, anchor_gt_batch)
                        a_sam = anchor_sam_criterion(
                            anchor_pred.unsqueeze(-1).unsqueeze(-1),
                            anchor_gt_batch.unsqueeze(-1).unsqueeze(-1)
                        )
                        loss = loss + 0.1 * a_mse + 0.1 * a_sam

                if scaler:
                    scaler.scale(loss).backward()
                    scaler.step(optimizer)
                    scaler.update()
                    optimizer.zero_grad()
                else:
                    loss.backward()
                    optimizer.step()
                    optimizer.zero_grad()

                train_loss += loss.item()
                global_step += 1
                pbar.set_postfix({"Loss": f"{loss.item():.6f}"})

            avg_train_loss = train_loss / len(train_loader)

            # ========= 验证 =========
            model.eval()
            val_loss = 0.0
            with torch.no_grad():
                for batch in val_loader:
                    if use_anchor:
                        inputs, targets, anchor_gt = batch
                        anchor_gt = anchor_gt.to(device)
                    else:
                        inputs, targets = batch

                    inputs = inputs.to(device)
                    targets = targets.to(device)

                    if use_anchor:
                        outputs, anchor_pred = model(inputs)
                    else:
                        outputs = model(inputs)

                    outputs_stage = outputs[:, active_channels, :, :]
                    targets_stage = targets[:, active_channels, :, :]

                    main_loss = recon_criterion(outputs_stage, targets_stage)
                    sam_loss = sam_criterion(outputs_stage, targets_stage)
                    smooth_loss = smooth_criterion(outputs_stage)
                    loss = main_loss + alpha_sam * sam_loss + beta_smooth * smooth_loss

                    if use_anchor:
                        if anchor_gt.dim() == 1:
                            anchor_gt_batch = anchor_gt.unsqueeze(0).repeat(outputs.shape[0], 1)
                        else:
                            anchor_gt_batch = anchor_gt
                        a_mse = anchor_mse_criterion(anchor_pred, anchor_gt_batch)
                        a_sam = anchor_sam_criterion(
                            anchor_pred.unsqueeze(-1).unsqueeze(-1),
                            anchor_gt_batch.unsqueeze(-1).unsqueeze(-1)
                        )
                        loss = loss + 0.1 * a_mse + 0.1 * a_sam

                    val_loss += loss.item()

            avg_val_loss = val_loss / len(val_loader)

            # LR schedule（全程共享一个 scheduler）
            if global_step <= warmup_epochs * len(train_loader):
                warmup_scheduler.step()
            else:
                main_scheduler.step()

            writer.add_scalar(f'Stage{stage_id}/Loss/Train', avg_train_loss, global_step)
            writer.add_scalar(f'Stage{stage_id}/Loss/Val', avg_val_loss, global_step)

            print(f"✅ Stage {stage_id} Epoch {epoch}: Train {avg_train_loss:.6f}, Val {avg_val_loss:.6f}")

            if avg_val_loss < best_val_loss:
                best_val_loss = avg_val_loss
                torch.save({'model_state_dict': model.state_dict()}, stage_best_path)
                print(f"💾 保存 Stage {stage_id} 当前最优模型到: {stage_best_path}")

        # 下一个 stage 用本 stage 最优权重 warm-start
        if os.path.exists(stage_best_path):
            checkpoint = torch.load(stage_best_path, map_location=device)
            model.load_state_dict(checkpoint['model_state_dict'])
            last_stage_best_path = stage_best_path

    # ========= 最终测试（用最后一个 stage 的 best 权重） =========
    print("\n📌 使用最终 stage 的最优模型在测试集上评估...")
    final_ckpt_path = last_stage_best_path if last_stage_best_path is not None else best_model_path
    if os.path.exists(final_ckpt_path):
        checkpoint = torch.load(final_ckpt_path, map_location=device)
        model.load_state_dict(checkpoint['model_state_dict'])

    test_results = evaluate_unified_model(
        model, test_loader, device,
        norm_params_list=norm_params_list,
        band_indices=label_band_indices
    )
    # 修复 numpy.float32 不能被 json 序列化的问题
    test_results_serializable = {k: float(v) if hasattr(v, 'item') or isinstance(v, np.floating) else v for k, v in test_results.items()}
    print("📊 Test Results:", json.dumps(test_results_serializable, indent=2, ensure_ascii=False))

    summary = {
        'strategy': strategy_name_with_suffix,
        'timestamp': datetime.now().isoformat(),
        'test_results': test_results,
        'use_learned_pe': use_learned_pe,
        'use_anchor': use_anchor,
        'use_cascade': use_cascade,
        'num_stages': num_stages if use_cascade else 1,
        'input_design': '5-band + 6-7-6-7-6 → 32ch',
    }
    summary_file = os.path.join(strategy_dir, "unified_training_summary.json")
    with open(summary_file, 'w', encoding='utf-8') as f:
        json.dump(summary, f, indent=2, ensure_ascii=False)
    print(f"📝 统一模型训练总结已保存到: {summary_file}")

    # 再存一份统一 best 模型
    if final_ckpt_path != best_model_path and os.path.exists(final_ckpt_path):
        torch.save(torch.load(final_ckpt_path, map_location='cpu'), best_model_path)

    return best_model_path, test_results


# ========= CLI =========
def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--strategy', type=str, default='physical_unified',
                        help='仅作为命名用')
    parser.add_argument('--batch_size', type=int, default=4)
    parser.add_argument('--device', type=str, default='cuda')
    group = parser.add_mutually_exclusive_group()
    group.add_argument('--use_anchor', dest='use_anchor', action='store_true', help='开启 Anchor 监督（默认开启）')
    group.add_argument('--no_use_anchor', dest='use_anchor', action='store_false', help='关闭 Anchor 监督')
    parser.set_defaults(use_anchor=True)
    parser.add_argument('--use_learned_pe', action='store_true', default=False,
                        help='是否启用 learned channel positional encoding')
    parser.add_argument('--use_3d', action='store_true', default=False,
                        help='是否使用 3D SwinUNETR（把 32 slices 当作深度维度 D）')
    parser.add_argument('--use_cascade', action='store_true', default=False,
                        help='是否启用 curriculum / cascade（分阶段增加监督 band）')
    parser.add_argument('--num_stages', type=int, default=4,
                        help='cascade 的阶段数（仅在 use_cascade=True 时生效）')
    parser.add_argument('--epochs', type=int, default=120)
    parser.add_argument('--lr', type=float, default=2e-4)
    parser.add_argument('--weight_decay', type=float, default=5e-6)
    parser.add_argument('--data_type', type=str, default='raw',
                        help='保留参数（目前只用 raw）')

    args = parser.parse_args()

    device = torch.device(args.device if torch.cuda.is_available() else 'cpu')
    print(f"🖥 使用设备: {device}")

    train_unified_model_5to219(
        batch_size=args.batch_size,
        device=device,
        strategy_name=args.strategy,
        use_anchor=args.use_anchor,
        use_learned_pe=args.use_learned_pe,
        use_3d=args.use_3d,
        use_cascade=args.use_cascade,
        num_stages=args.num_stages,
        num_epochs=args.epochs,
        lr=args.lr,
        weight_decay=args.weight_decay
    )


if __name__ == "__main__":
    main()
