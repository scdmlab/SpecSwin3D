﻿# train/overnight_training.py - 睡觉专用全自动训练脚本
import subprocess
import time
import os
import json
from datetime import datetime
import torch

def log_message(message):
    """带时间戳的日志"""
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    print(f"[{timestamp}] {message}")
    
    # 同时写入日志文件
    with open("overnight_training.log", "a", encoding='utf-8') as f:
        f.write(f"[{timestamp}] {message}\n")

def check_gpu_memory():
    """检查GPU内存"""
    if torch.cuda.is_available():
        memory_gb = torch.cuda.get_device_properties(0).total_memory / 1024**3
        gpu_name = torch.cuda.get_device_name(0)
        return memory_gb, gpu_name
    return 0, "CPU"

def estimate_batch_size(gpu_memory_gb):
    """根据GPU内存估算合适的batch size"""
    if gpu_memory_gb >= 32:
        return 48  # 大显存GPU
    elif gpu_memory_gb >= 24:
        return 32  # 高端GPU
    elif gpu_memory_gb >= 16:
        return 24  # 中高端GPU
    elif gpu_memory_gb >= 12:
        return 16  # 中端GPU
    elif gpu_memory_gb >= 8:
        return 12  # 入门GPU
    else:
        return 8   # 保守设置

def run_strategy_training(strategy, batch_size, start_level=0, end_level=0):
    """运行单个策略的训练"""
    log_message(f"🚀 开始训练策略: {strategy}")
    log_message(f"   批次大小: {batch_size}")
    log_message(f"   级联层次: {start_level}-{end_level}")
    
    cmd = [
        "python", "train_swin_unetr_16.py",
        "--strategy", strategy,
        "--batch_size", str(batch_size),
        "--start_level", str(start_level),
        "--end_level", str(end_level),
        "--mixed_precision"
    ]
    
    start_time = time.time()
    
    try:
        # 运行训练
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=3600*4)  # 4小时超时
        
        end_time = time.time()
        duration = end_time - start_time
        
        if result.returncode == 0:
            log_message(f"✅ 策略 {strategy} 训练完成!")
            log_message(f"   耗时: {duration/3600:.1f} 小时")
            return {
                'strategy': strategy,
                'status': 'success',
                'duration_hours': duration/3600,
                'stdout': result.stdout[-1000:],  # 保留最后1000字符
                'batch_size': batch_size
            }
        else:
            log_message(f"❌ 策略 {strategy} 训练失败!")
            log_message(f"   错误: {result.stderr}")
            return {
                'strategy': strategy,
                'status': 'failed',
                'duration_hours': duration/3600,
                'error': result.stderr,
                'batch_size': batch_size
            }
    
    except subprocess.TimeoutExpired:
        log_message(f"⏰ 策略 {strategy} 训练超时 (4小时)")
        return {
            'strategy': strategy,
            'status': 'timeout',
            'duration_hours': 4.0,
            'batch_size': batch_size
        }
    except Exception as e:
        log_message(f"💥 策略 {strategy} 出现异常: {e}")
        return {
            'strategy': strategy,
            'status': 'error',
            'error': str(e),
            'batch_size': batch_size
        }

def main():
    log_message("🌙 开始夜间全自动训练！祝您好梦~")
    
    # 检查硬件
    gpu_memory, gpu_name = check_gpu_memory()
    batch_size = estimate_batch_size(gpu_memory)
    
    log_message(f"🖥️ 硬件信息:")
    log_message(f"   GPU: {gpu_name}")
    log_message(f"   显存: {gpu_memory:.1f} GB")
    log_message(f"   推荐批次大小: {batch_size}")
    
    # 定义要测试的策略
    strategies = [
        'physical',      # 物理特性策略 (推荐)
        'uniform',       # 均匀分布策略
        'importance',    # 重要性策略
        'correlation'    # 相关性策略
    ]
    
    # 训练结果记录
    results = []
    total_start_time = time.time()
    
    log_message(f"📋 计划训练 {len(strategies)} 个策略")
    log_message("="*60)
    
    # 逐个训练策略
    for i, strategy in enumerate(strategies, 1):
        log_message(f"🎯 [{i}/{len(strategies)}] 当前策略: {strategy}")
        
        # 运行训练
        result = run_strategy_training(
            strategy=strategy,
            batch_size=batch_size,
            start_level=0,
            end_level=0  # 只训练第一层，快速验证
        )
        
        results.append(result)
        
        # 保存中间结果
        with open("overnight_results.json", "w", encoding='utf-8') as f:
            json.dump(results, f, indent=2, ensure_ascii=False)
        
        log_message("-"*40)
        
        # 如果失败太多，可以选择继续或停止
        failed_count = sum(1 for r in results if r['status'] != 'success')
        if failed_count >= 2:
            log_message(f"⚠️ 已有 {failed_count} 个策略失败，但继续训练...")
    
    # 总结报告
    total_end_time = time.time()
    total_duration = total_end_time - total_start_time
    
    log_message("="*60)
    log_message("🎉 夜间训练完成！训练报告:")
    log_message(f"⏱️ 总耗时: {total_duration/3600:.1f} 小时")
    
    success_count = sum(1 for r in results if r['status'] == 'success')
    failed_count = len(results) - success_count
    
    log_message(f"✅ 成功: {success_count} 个策略")
    log_message(f"❌ 失败: {failed_count} 个策略")
    
    # 详细结果
    log_message("\n📊 详细结果:")
    for result in results:
        status_emoji = {"success": "✅", "failed": "❌", "timeout": "⏰", "error": "💥"}
        emoji = status_emoji.get(result['status'], "❓")
        
        log_message(f"   {emoji} {result['strategy']}: {result['status']} "
                   f"({result.get('duration_hours', 0):.1f}h)")
        
        if result['status'] == 'success' and 'stdout' in result:
            # 尝试提取最终测试结果
            stdout = result['stdout']
            if "测试结果:" in stdout:
                log_message(f"      {stdout.split('测试结果:')[-1][:200]}...")
    
    # 保存完整结果
    final_report = {
        'timestamp': datetime.now().isoformat(),
        'total_duration_hours': total_duration/3600,
        'gpu_info': {'name': gpu_name, 'memory_gb': gpu_memory},
        'batch_size': batch_size,
        'summary': {
            'total_strategies': len(strategies),
            'successful': success_count,
            'failed': failed_count
        },
        'detailed_results': results
    }
    
    with open("overnight_final_report.json", "w", encoding='utf-8') as f:
        json.dump(final_report, f, indent=2, ensure_ascii=False)
    
    log_message("💾 完整报告已保存至: overnight_final_report.json")
    log_message("🌅 早上好！快去查看您的训练结果吧！")

if __name__ == "__main__":
    main()
