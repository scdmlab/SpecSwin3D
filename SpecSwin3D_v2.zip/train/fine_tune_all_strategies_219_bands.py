﻿import sys
import os
import json
import contextlib
import glob
import time
from datetime import datetime
from pathlib import Path

# Add parent directory to path
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

# 🔥 修改：使用相对路径，适配服务器环境
# CHECKPOINT_DIR = r"D:\wisc\SpecTran\checkpoints"  # 注释掉本地路径
# BASE_DIR = r"D:\wisc\SpecTran\codes\Swin-Unetr\Swin-UNETR-Clean\dataset"

# 🔥 新增：自动检测环境并设置路径
def get_environment_paths():
    """自动检测运行环境并返回正确的路径"""
    current_dir = os.path.dirname(os.path.abspath(__file__))  # train目录
    project_root = os.path.dirname(current_dir)  # 项目根目录
    
    # 检测是否在服务器环境
    if os.name == 'posix':  # Linux/Unix系统
        print("🐧 检测到Linux环境")
        # 服务器路径配置 - checkpoint与train同级
        base_dir = os.path.join(project_root, "dataset")
        checkpoint_dir = os.path.join(project_root, "checkpoints")  # 🔥 与train同级
    else:  # Windows系统
        print("🪟 检测到Windows环境")
        # 本地路径配置 - checkpoint与train同级
        base_dir = os.path.join(project_root, "dataset")
        checkpoint_dir = os.path.join(project_root, "checkpoints")  # 🔥 与train同级
    
    return base_dir, checkpoint_dir

# 获取环境路径
BASE_DIR, CHECKPOINT_DIR = get_environment_paths()

print(f"🔧 环境路径设置:")
print(f"   BASE_DIR: {BASE_DIR}")
print(f"   CHECKPOINT_DIR: {CHECKPOINT_DIR}")
print(f"   CHECKPOINT_DIR存在: {os.path.exists(CHECKPOINT_DIR)}")

import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import Dataset, DataLoader
from tqdm import tqdm
import numpy as np
from torch.utils.tensorboard import SummaryWriter
import argparse

# 导入你的现有模块
from train.train_swin_unetr_16 import (
    SwinUNETR_SingleBand, SingleBandDataset, 
    get_spectral_similarity, evaluate_model,
    denormalize_prediction, create_single_band_loaders  # 🔥 添加这个导入
)

def test_checkpoint_access():
    """测试checkpoint访问"""
    print(f"\n🔍 测试checkpoint访问")
    print(f"📁 Checkpoint目录: {CHECKPOINT_DIR}")
    print(f"   目录存在: {os.path.exists(CHECKPOINT_DIR)}")
    
    if os.path.exists(CHECKPOINT_DIR):
        try:
            items = os.listdir(CHECKPOINT_DIR)
            print(f"📋 目录内容 ({len(items)} 项): {items}")
            
            # 测试correlation_importance
            test_strategy = "correlation_importance"
            test_path = os.path.join(CHECKPOINT_DIR, test_strategy)
            print(f"\n🎯 测试策略: {test_strategy}")
            print(f"   策略目录: {test_path}")
            print(f"   策略目录存在: {os.path.exists(test_path)}")
            
            if os.path.exists(test_path):
                strategy_items = os.listdir(test_path)
                print(f"   策略目录内容: {strategy_items}")
                
                models_dir = os.path.join(test_path, "models")
                print(f"   模型目录: {models_dir}")
                print(f"   模型目录存在: {os.path.exists(models_dir)}")
                
                if os.path.exists(models_dir):
                    model_files = os.listdir(models_dir)
                    print(f"   模型文件数量: {len(model_files)}")
                    if model_files:
                        print(f"   前5个模型文件: {model_files[:5]}")
                        
                        # 测试glob模式
                        pattern = os.path.join(models_dir, "band_*.pth")
                        matched_files = glob.glob(pattern)
                        print(f"   Glob匹配文件数: {len(matched_files)}")
                else:
                    print(f"   ❌ 模型目录不存在")
            else:
                print(f"   ❌ 策略目录不存在")
        except Exception as e:
            print(f"   ❌ 访问目录失败: {e}")
    else:
        print(f"   ❌ Checkpoint目录不存在")

# 其余代码保持不变，但修改get_available_strategies函数
def get_available_strategies(checkpoint_dir):
    """获取所有可用的策略"""
    print(f"\n🔍 检查checkpoint目录: {checkpoint_dir}")
    print(f"   目录存在: {os.path.exists(checkpoint_dir)}")
    
    strategies = []
    
    if not os.path.exists(checkpoint_dir):
        print(f"❌ Checkpoint目录不存在: {checkpoint_dir}")
        return strategies
    
    try:
        # 列出所有子目录
        all_items = os.listdir(checkpoint_dir)
        print(f"📁 checkpoint目录下的所有项目 ({len(all_items)}): {all_items}")
        
        exclude_dirs = ['backup_old_training', 'importance_analysis']
        
        for item in all_items:
            item_path = os.path.join(checkpoint_dir, item)
            
            if os.path.isdir(item_path) and item not in exclude_dirs:
                print(f"\n🔍 检查策略目录: {item}")
                
                # 检查是否有models目录
                models_dir = os.path.join(item_path, "models")
                print(f"   模型目录: {models_dir}")
                print(f"   模型目录存在: {os.path.exists(models_dir)}")
                
                if os.path.exists(models_dir):
                    try:
                        # 使用两种方式检查模型文件
                        all_files = os.listdir(models_dir)
                        pth_files = [f for f in all_files if f.endswith('.pth')]
                        band_files = [f for f in pth_files if f.startswith('band_')]
                        
                        print(f"   总文件数: {len(all_files)}")
                        print(f"   .pth文件数: {len(pth_files)}")
                        print(f"   band_*.pth文件数: {len(band_files)}")
                        
                        if band_files:
                            print(f"   前3个band文件: {band_files[:3]}")
                            strategies.append((item, len(band_files)))
                            print(f"   ✅ 策略 {item} 可用 ({len(band_files)} models)")
                        else:
                            print(f"   ❌ 策略 {item} 无band模型文件")
                            if pth_files:
                                print(f"   其他.pth文件: {pth_files[:3]}")
                    except Exception as e:
                        print(f"   ❌ 检查模型文件失败: {e}")
                else:
                    print(f"   ❌ 策略 {item} 无models目录")
    except Exception as e:
        print(f"❌ 列出checkpoint目录失败: {e}")
    
    print(f"\n📊 找到 {len(strategies)} 个可用策略")
    return sorted(strategies, key=lambda x: x[1], reverse=True)

def main():
    # 🔥 添加命令行参数解析
    parser = argparse.ArgumentParser(description='全策略219波段Fine-tuning')
    parser.add_argument('--strategy', type=str, default=None,
                       help='指定要处理的策略名称')
    parser.add_argument('--checkpoint_dir', type=str, default=None,
                       help='Checkpoint目录路径')
    parser.add_argument('--base_dir', type=str, default=None,
                       help='数据目录路径')
    parser.add_argument('--batch_size', type=int, default=64,
                       help='批次大小')
    parser.add_argument('--device', type=str, default='cuda',
                       help='训练设备')
    parser.add_argument('--start_band', type=int, default=0,
                       help='起始波段')
    parser.add_argument('--end_band', type=int, default=223,  
                       help='结束波段')
    parser.add_argument('--dry_run', action='store_true',
                       help='干运行模式，只显示计划不执行训练')
    parser.add_argument('--run_actual', action='store_true',
                       help='执行实际的Fine-tuning训练')
    
    args = parser.parse_args()
    
    # 🔥 修复：使用局部变量而不是修改全局变量
    checkpoint_dir = args.checkpoint_dir if args.checkpoint_dir else CHECKPOINT_DIR
    base_dir = args.base_dir if args.base_dir else BASE_DIR
    
    print("🚀 开始全策略219波段Fine-tuning")
    print(f"📁 使用checkpoint目录: {checkpoint_dir}")
    print(f"📁 使用数据目录: {base_dir}")
    
    # 首先测试checkpoint访问
    test_checkpoint_access_with_path(checkpoint_dir)
    
    # 获取可用策略
    available_strategies = get_available_strategies(checkpoint_dir)
    
    if not available_strategies:
        print("\n❌ 未找到任何可用策略")
        return
    
    print(f"\n📋 发现 {len(available_strategies)} 个可用策略:")
    for i, (strategy, model_count) in enumerate(available_strategies, 1):
        print(f"   {i:2d}. {strategy:<30} ({model_count} models)")
    
    # 🔥 根据参数选择策略
    if args.strategy:
        if args.strategy not in [s[0] for s in available_strategies]:
            print(f"❌ 指定的策略 '{args.strategy}' 不存在")
            print(f"💡 可用策略: {[s[0] for s in available_strategies]}")
            return
        strategies_to_process = [args.strategy]
    else:
        # 处理所有策略
        strategies_to_process = [s[0] for s in available_strategies]
    
    print(f"\n🎯 将处理的策略: {strategies_to_process}")
    
    # 🔥 处理每个策略
    for strategy in strategies_to_process:
        print(f"\n{'='*80}")
        print(f"🎯 处理策略: {strategy}")
        print(f"{'='*80}")
        
        try:
            # 创建Fine-tuner，传入正确的checkpoint_dir
            fine_tuner = AllBandFineTuner(strategy, checkpoint_dir)
            
            # 🔥 执行Fine-tuning计划
            plan = fine_tuner.run_full_spectrum_fine_tuning(
                device=args.device,
                batch_size=args.batch_size,
                start_band=args.start_band,
                end_band=args.end_band,
                dry_run=not args.run_actual  # 如果指定了run_actual，则不是干运行
            )
            
            print(f"✅ 策略 {strategy} 处理完成")
            
        except Exception as e:
            print(f"❌ 策略 {strategy} 处理失败: {e}")
            import traceback
            traceback.print_exc()
            continue

def test_checkpoint_access_with_path(checkpoint_dir):
    """测试checkpoint访问 - 使用指定路径"""
    print(f"\n🔍 测试checkpoint访问")
    print(f"📁 Checkpoint目录: {checkpoint_dir}")
    print(f"   目录存在: {os.path.exists(checkpoint_dir)}")
    
    if os.path.exists(checkpoint_dir):
        try:
            items = os.listdir(checkpoint_dir)
            print(f"📋 目录内容 ({len(items)} 项): {items}")
            
            # 测试correlation_importance
            test_strategy = "correlation_importance"
            test_path = os.path.join(checkpoint_dir, test_strategy)
            print(f"\n🎯 测试策略: {test_strategy}")
            print(f"   策略目录: {test_path}")
            print(f"   策略目录存在: {os.path.exists(test_path)}")
            
            if os.path.exists(test_path):
                strategy_items = os.listdir(test_path)
                print(f"   策略目录内容: {strategy_items}")
                
                models_dir = os.path.join(test_path, "models")
                print(f"   模型目录: {models_dir}")
                print(f"   模型目录存在: {os.path.exists(models_dir)}")
                
                if os.path.exists(models_dir):
                    model_files = os.listdir(models_dir)
                    print(f"   模型文件数量: {len(model_files)}")
                    if model_files:
                        print(f"   前5个模型文件: {model_files[:5]}")
                        
                        # 测试glob模式
                        pattern = os.path.join(models_dir, "band_*.pth")
                        matched_files = glob.glob(pattern)
                        print(f"   Glob匹配文件数: {len(matched_files)}")
                else:
                    print(f"   ❌ 模型目录不存在")
            else:
                print(f"   ❌ 策略目录不存在")
        except Exception as e:
            print(f"   ❌ 访问目录失败: {e}")
    else:
        print(f"   ❌ Checkpoint目录不存在")

# 🔥 修改AllBandFineTuner的构造函数，移除默认值
class AllBandFineTuner:
    """全波段Fine-tuning类"""
    
    def __init__(self, source_strategy, checkpoint_dir):
        self.source_strategy = source_strategy
        self.checkpoint_dir = checkpoint_dir
        self.source_dir = os.path.join(checkpoint_dir, source_strategy)
        self.models_dir = os.path.join(self.source_dir, "models")
        
        print(f"🔍 检查源策略目录:")
        print(f"   源目录: {self.source_dir}")
        print(f"   模型目录: {self.models_dir}")
        print(f"   源目录存在: {os.path.exists(self.source_dir)}")
        print(f"   模型目录存在: {os.path.exists(self.models_dir)}")
        
        # 创建输出目录
        self.output_strategy = f"{source_strategy}_full_219_bands"
        self.output_dir = os.path.join(checkpoint_dir, self.output_strategy)
        self.output_models_dir = os.path.join(self.output_dir, "models")
        self.output_logs_dir = os.path.join(self.output_dir, "tensorboard_logs")
        
        # 创建目录
        os.makedirs(self.output_dir, exist_ok=True)
        os.makedirs(self.output_models_dir, exist_ok=True)
        os.makedirs(self.output_logs_dir, exist_ok=True)
        
        print(f"🎯 全波段Fine-tuning初始化")
        print(f"📂 源策略: {source_strategy}")
        print(f"📂 源模型目录: {self.models_dir}")
        print(f"📂 输出策略: {self.output_strategy}")
        print(f"📂 输出目录: {self.output_dir}")
        
        # 加载源策略信息
        self.load_source_strategy_info()
        
        # 输入波段（与你的训练代码一致）
        self.input_bands = [30, 20, 9, 40, 52]  # 5个输入波段
        self.total_bands = 224  # 0-223共224个波段
        self.target_model_count = 219  # 224-5=219个模型
        
        print(f"📊 波段配置:")
        print(f"   总波段数: {self.total_bands} (0-{self.total_bands-1})")
        print(f"   输入波段: {self.input_bands}")
        print(f"   目标模型数: {self.target_model_count}")
    
    def load_source_strategy_info(self):
        """加载源策略信息"""
        print(f"📊 加载源策略 {self.source_strategy} 信息...")
        
        # 加载训练摘要
        summary_file = os.path.join(self.source_dir, "training_summary.json")
        self.trained_bands = []
        self.band_performance = {}
        
        print(f"🔍 查找摘要文件: {summary_file}")
        print(f"   摘要文件存在: {os.path.exists(summary_file)}")
        
        if os.path.exists(summary_file):
            try:
                with open(summary_file, 'r') as f:
                    self.strategy_data = json.load(f)
                
                print(f"📋 摘要文件内容键: {list(self.strategy_data.keys())}")
                
                # 提取已训练波段
                if 'training_results' in self.strategy_data:
                    for band_key, result in self.strategy_data['training_results'].items():
                        band_num = int(band_key.split('_')[1])
                        self.trained_bands.append(band_num)
                        self.band_performance[band_num] = {
                            'rmse': result.get('rmse', float('inf')),
                            'mae': result.get('mae', float('inf')),
                            'model_path': os.path.join(self.models_dir, f"band_{band_num:03d}_best_model.pth")
                        }
                
                print(f"✅ 从训练摘要加载了 {len(self.trained_bands)} 个波段")
                
            except Exception as e:
                print(f"⚠️ 读取训练摘要失败: {e}")
                self.strategy_data = {}
        
        # 如果没有摘要文件，扫描模型文件
        if not self.trained_bands:
            print("📁 扫描模型文件...")
            model_pattern = os.path.join(self.models_dir, "band_*_best_model.pth")
            print(f"🔍 扫描模式: {model_pattern}")
            
            model_files = glob.glob(model_pattern)
            print(f"📁 找到 {len(model_files)} 个模型文件")
            
            if model_files:
                print(f"📋 前5个模型文件:")
                for model_file in model_files[:5]:
                    print(f"   - {os.path.basename(model_file)}")
            
            for model_file in model_files:
                try:
                    filename = os.path.basename(model_file)
                    band_num = int(filename.split('_')[1])
                    self.trained_bands.append(band_num)
                    self.band_performance[band_num] = {
                        'rmse': float('inf'),
                        'mae': float('inf'),
                        'model_path': model_file
                    }
                except Exception as e:
                    print(f"⚠️ 解析文件名失败 {filename}: {e}")
                    continue
            
            print(f"✅ 从文件扫描加载了 {len(self.trained_bands)} 个波段")
        
        self.trained_bands = sorted(self.trained_bands)
        
        print(f"📋 已训练波段: {self.trained_bands[:10]}{'...' if len(self.trained_bands) > 10 else ''}")
        print(f"📊 波段范围: {min(self.trained_bands) if self.trained_bands else 'N/A'} - {max(self.trained_bands) if self.trained_bands else 'N/A'}")
    
    def find_best_source_model(self, target_band):
        """为目标波段找到最佳源模型"""
        
        # 🔥 修改：如果目标波段是级联训练过的波段，直接使用
        if target_band in self.trained_bands:
            return self.band_performance[target_band]['model_path'], 1.0, target_band
        
        # 🔥 修改：输入波段现在可以作为源模型（如果被训练过）
        # 但不能作为fine-tuning的目标
        if target_band in self.input_bands:
            raise ValueError(f"波段 {target_band} 是输入波段，不需要重建")
        
        # 🔥 修改：在所有训练过的波段中找最相似的（包括输入波段）
        best_similarity = -1
        best_source_band = None
        best_model_path = None
        
        for source_band in self.trained_bands:  # 使用所有训练过的波段
            # 计算相似性
            spectral_sim = get_spectral_similarity(target_band, source_band)
            
            # 考虑模型性能
            performance_weight = 1.0 / (1.0 + self.band_performance[source_band]['rmse'])
            
            # 综合评分
            combined_score = 0.7 * spectral_sim + 0.3 * performance_weight
            
            if combined_score > best_similarity:
                best_similarity = combined_score
                best_source_band = source_band
                best_model_path = self.band_performance[source_band]['model_path']
        
        if best_model_path and os.path.exists(best_model_path):
            return best_model_path, best_similarity, best_source_band
        else:
            return None, 0.0, None
    
    def get_fine_tuning_params(self, similarity_score, target_band, source_band):
        """根据相似度和波段特性获取Fine-tuning参数"""
        
        # 基础参数
        base_params = {
            'epochs': 50,
            'lr': 1e-4,
            'weight_decay': 5e-6,
            'warmup_epochs': 5,
            'gradient_clip': 1.0,
            'accumulation_steps': 1
        }
        
        # 根据相似度调整
        if similarity_score > 0.8:
            # 高相似度：保守Fine-tuning
            base_params.update({
                'epochs': 30,
                'lr': 5e-5,
                'warmup_epochs': 3
            })
        elif similarity_score > 0.6:
            # 中等相似度：适中Fine-tuning
            base_params.update({
                'epochs': 50,
                'lr': 1e-4,
                'warmup_epochs': 5
            })
        else:
            # 低相似度：更激进的Fine-tuning
            base_params.update({
                'epochs': 80,
                'lr': 2e-4,
                'warmup_epochs': 8
            })
        
        # 根据波段距离调整
        band_distance = abs(target_band - source_band)
        if band_distance < 5:
            # 相邻波段：减少训练轮数
            base_params['epochs'] = max(20, int(base_params['epochs'] * 0.7))
        elif band_distance > 50:
            # 远距离波段：增加训练轮数
            base_params['epochs'] = int(base_params['epochs'] * 1.3)
        
        return base_params
    
    def run_full_spectrum_fine_tuning(self, device='cuda', batch_size=8, start_band=0, end_band=223, dry_run=True):
        """运行全光谱Fine-tuning"""
        print(f"🚀 开始全光谱Fine-tuning: {self.source_strategy} → {self.output_strategy}")
        
        # 🔥 修改：总共224个波段（0-223），减去5个input bands
        all_bands = list(range(start_band, end_band + 1))  # 0-223，共224个波段
        
        # 🔥 关键修改：需要重建的是224个波段减去5个input bands = 219个模型
        target_bands = [band for band in all_bands if band not in self.input_bands]
        missing_bands = [band for band in target_bands if band not in self.trained_bands]
        
        print(f"📋 波段统计:")
        print(f"   全部波段: {len(all_bands)} ({start_band}-{end_band})")
        print(f"   输入波段: {len(self.input_bands)} {self.input_bands}")
        print(f"   目标重建波段: {len(target_bands)} (全部224-输入5=219)")
        print(f"   已级联训练: {len(self.trained_bands)} (包含输入波段: {[b for b in self.trained_bands if b in self.input_bands]})")
        print(f"   需要Fine-tune: {len(missing_bands)} (目标219-级联{len(self.trained_bands)})")
        
        # 🔥 验证总数
        expected_total_models = 219  # 224-5=219
        predicted_total = len(self.trained_bands) + len(missing_bands)
        
        print(f"📊 模型数量验证:")
        print(f"   期望总模型数: {expected_total_models} (224波段-5输入)")
        print(f"   预测总模型数: {predicted_total} (级联{len(self.trained_bands)}+Fine-tune{len(missing_bands)})")
        
        if predicted_total == expected_total_models:
            print(f"✅ 数量验证通过！")
        else:
            difference = abs(predicted_total - expected_total_models)
            print(f"⚠️ 数量不匹配，差异: {difference}")
            if predicted_total < expected_total_models:
                print(f"   还需要训练 {difference} 个波段")
            else:
                print(f"   超出预期 {difference} 个波段")
        
        if not missing_bands:
            print("✅ 所有219个模型都已训练完成！")
            return {}
        
        print(f"📋 需要Fine-tune的波段: {missing_bands[:20]}{'...' if len(missing_bands) > 20 else ''}")
        
        # 为每个缺失波段找到最佳源模型
        fine_tuning_plan = {}
        
        # 🔥 处理所有缺失波段，不只是前10个
        total_bands = len(missing_bands)
        
        for i, target_band in enumerate(missing_bands, 1):
            print(f"\n📋 规划波段 {i}/{total_bands}: Band {target_band}")
            
            try:
                source_model_path, similarity, source_band = self.find_best_source_model(target_band)
                
                if source_model_path:
                    params = self.get_fine_tuning_params(similarity, target_band, source_band)
                    fine_tuning_plan[target_band] = {
                        'source_band': source_band,
                        'source_model_path': source_model_path,
                        'similarity': similarity,
                        'params': params
                    }
                    
                    print(f"   ✅ Band {target_band:3d} ← Band {source_band:3d} "
                          f"(相似度: {similarity:.3f}, epochs: {params['epochs']}, lr: {params['lr']:.6f})")
                else:
                    print(f"   ❌ Band {target_band:3d}: 无法找到合适的源模型")
                    
            except Exception as e:
                print(f"   ❌ Band {target_band:3d}: 规划失败 - {e}")
        
        print(f"\n📊 Fine-tuning计划完成:")
        print(f"   可执行计划: {len(fine_tuning_plan)}")
        print(f"   无法规划: {total_bands - len(fine_tuning_plan)}")
        
        if dry_run:
            print(f"\n🧪 干运行完成！")
            print(f"🚀 要执行实际Fine-tuning，请使用 --run_actual 参数")
            
            # 保存计划到文件
            plan_file = os.path.join(self.output_dir, "fine_tuning_plan.json")
            with open(plan_file, 'w') as f:
                json.dump({
                    'source_strategy': self.source_strategy,
                    'total_missing_bands': total_bands,
                    'executable_plans': len(fine_tuning_plan),
                    'plan_details': fine_tuning_plan
                }, f, indent=2, default=str)
            
            print(f"💾 计划已保存: {plan_file}")
            return fine_tuning_plan
        
        # 🔥 实际执行Fine-tuning
        print(f"\n🔥 开始实际Fine-tuning...")
        return self.execute_fine_tuning(fine_tuning_plan, device, batch_size)
    
    def execute_fine_tuning(self, fine_tuning_plan, device, batch_size):
        """执行实际的Fine-tuning"""
        print(f"🚀 执行Fine-tuning: {len(fine_tuning_plan)} 个波段")
        
        results = {}
        failed_bands = []
        
        start_time = time.time()
        
        try:
            # 创建TensorBoard writer
            writer = SummaryWriter(self.output_logs_dir)
            
            for i, (target_band, plan) in enumerate(fine_tuning_plan.items(), 1):
                print(f"\n{'='*60}")
                print(f"🎯 Fine-tuning {i}/{len(fine_tuning_plan)}: Band {target_band}")
                print(f"{'='*60}")
                
                try:
                    result = self.fine_tune_single_band(
                        target_band, plan, device, batch_size, writer
                    )
                    
                    if result:
                        results[f"band_{target_band:03d}"] = result
                        print(f"✅ Band {target_band} Fine-tuning成功")
                    else:
                        failed_bands.append(target_band)
                        print(f"❌ Band {target_band} Fine-tuning失败")
                
                except Exception as e:
                    print(f"❌ Band {target_band} Fine-tuning异常: {e}")
                    failed_bands.append(target_band)
                    continue
            
            writer.close()
            
        except Exception as e:
            print(f"❌ Fine-tuning执行失败: {e}")
        
        total_time = time.time() - start_time
        
        # Save results
        self.save_fine_tuning_results(results, failed_bands, total_time)
        
        print(f"\n🎉 Fine-tuning完成!")
        print(f"✅ 成功: {len(results)} 个波段")
        print(f"❌ 失败: {len(failed_bands)} 个波段")
        print(f"⏱️ 总时间: {total_time/3600:.2f} 小时")
        
        return results
    
    def fine_tune_single_band(self, target_band, plan, device, batch_size, writer):
        print(f"🔥 Fine-tuning Band {target_band}")
        print(f"   源波段: {plan['source_band']}")
        print(f"   相似度: {plan['similarity']:.4f}")
        
        start_time = time.time()
        
        try:
            # 1. 加载源模型
            print(f"📂 加载源模型: {plan['source_model_path']}")
            checkpoint = torch.load(plan['source_model_path'], map_location=device)
            
            # 2. 🔥 与train_swin_unetr_16保持一致：使用相同的模型创建方式
            model = SwinUNETR_SingleBand(
                in_channels=16,  # 与原始训练一致
                img_size=(64, 64)  # 使用相同的图像尺寸
            ).to(device)
            
            print(f"✅ 模型创建成功")
            
            # 3. 加载预训练权重
            model.load_state_dict(checkpoint['model_state_dict'])
            print(f"✅ 源模型加载成功")
            
            # 4. 🔥 与train_swin_unetr_16保持一致：使用相同的数据加载器创建方式
            print(f"📊 创建数据加载器...")
            
            # 使用与原始训练相同的数据加载器函数
            train_loader, val_loader, test_loader = create_single_band_loaders(
                target_band_idx=target_band,
                batch_size=batch_size,
                num_workers=2  # 保持与原始训练一致
            )
            
            print(f"📊 训练集大小: {len(train_loader.dataset)}")
            print(f"📊 验证集大小: {len(val_loader.dataset)}")
            
            # 5. 🔥 获取归一化参数（与原始训练一致）
            dataset = train_loader.dataset
            if hasattr(dataset, 'dataset'):
                norm_params = dataset.dataset.get_norm_params()
            else:
                norm_params = dataset.get_norm_params()
            
            print(f"📊 归一化参数: {norm_params is not None}")
            
            # 6. 设置优化器和损失函数
            params = plan['params']
            optimizer = optim.AdamW(
                model.parameters(),
                lr=params['lr'],
                weight_decay=params['weight_decay']
            )
            
            criterion = nn.MSELoss()
            scheduler = optim.lr_scheduler.CosineAnnealingLR(
                optimizer, 
                T_max=params['epochs']
            )
            
            # 7. 实际训练循环
            print(f"🚀 开始训练 {params['epochs']} 轮...")
            
            best_val_loss = float('inf')
            best_model_path = os.path.join(
                self.output_models_dir, 
                f"band_{target_band:03d}_finetuned.pth"
            )
            
            for epoch in range(params['epochs']):
                # 训练阶段
                model.train()
                train_loss = 0.0
                train_batches = 0
                
                for batch_idx, (inputs, targets) in enumerate(tqdm(
                    train_loader, 
                    desc=f"Epoch {epoch+1}/{params['epochs']} - Train"
                )):
                    inputs, targets = inputs.to(device), targets.to(device)
                    
                    optimizer.zero_grad()
                    outputs = model(inputs)
                    loss = criterion(outputs, targets)
                    loss.backward()
                    
                    # 梯度裁剪
                    torch.nn.utils.clip_grad_norm_(
                        model.parameters(), 
                        params['gradient_clip']
                    )
                    
                    optimizer.step()
                    
                    train_loss += loss.item()
                    train_batches += 1
                
                # 验证阶段
                model.eval()
                val_loss = 0.0
                val_batches = 0
                
                with torch.no_grad():
                    for inputs, targets in tqdm(val_loader, desc="Validation"):
                        inputs, targets = inputs.to(device), targets.to(device)
                        outputs = model(inputs)
                        loss = criterion(outputs, targets)
                        
                        val_loss += loss.item()
                        val_batches += 1
                
                # 计算平均损失
                avg_train_loss = train_loss / train_batches
                avg_val_loss = val_loss / val_batches
                
                scheduler.step()
                
                # 记录到TensorBoard
                if writer:
                    writer.add_scalar(f'Loss/Train_Band_{target_band}', avg_train_loss, epoch)
                    writer.add_scalar(f'Loss/Val_Band_{target_band}', avg_val_loss, epoch)
                    writer.add_scalar(f'LR/Band_{target_band}', optimizer.param_groups[0]['lr'], epoch)
                
                print(f"Epoch {epoch+1:3d}: Train Loss: {avg_train_loss:.6f}, "
                    f"Val Loss: {avg_val_loss:.6f}, LR: {optimizer.param_groups[0]['lr']:.8f}")
                
                # 保存最佳模型
                if avg_val_loss < best_val_loss:
                    best_val_loss = avg_val_loss
                    torch.save({
                        'epoch': epoch,
                        'model_state_dict': model.state_dict(),
                        'optimizer_state_dict': optimizer.state_dict(),
                        'val_loss': avg_val_loss,
                        'target_band': target_band,
                        'source_band': plan['source_band'],
                        'similarity': plan['similarity'],
                        'source_strategy': self.source_strategy,
                        'fine_tuning_time': time.time() - start_time
                    }, best_model_path)
                    
                    print(f"💾 保存最佳模型: {best_model_path}")
            
            # 8. 🔥 最终评估，传入正确的norm_params参数
            print(f"📊 最终评估...")
            final_metrics = evaluate_model(model, test_loader, device, norm_params)
            
            training_time = time.time() - start_time
            
            result = {
                'target_band': target_band,
                'source_band': plan['source_band'],
                'similarity': plan['similarity'],
                'rmse': final_metrics.get('rmse', best_val_loss**0.5),
                'mae': final_metrics.get('mae', best_val_loss),
                'best_val_loss': best_val_loss,
                'training_time': training_time,
                'epochs_completed': params['epochs'],
                'model_path': best_model_path
            }
            
            # 🔥 添加原始尺度的评估结果
            if 'rmse_original' in final_metrics:
                result.update({
                    'rmse_original': final_metrics['rmse_original'],
                    'mae_original': final_metrics['mae_original'],
                    'norm_range': final_metrics.get('norm_range')
                })
            
            print(f"✅ Band {target_band} 训练完成!")
            print(f"   最佳验证损失: {best_val_loss:.6f}")
            print(f"   标准化RMSE: {final_metrics.get('rmse', 'N/A'):.6f}")
            print(f"   标准化MAE: {final_metrics.get('mae', 'N/A'):.6f}")
            if 'rmse_original' in final_metrics:
                print(f"   原始尺度RMSE: {final_metrics['rmse_original']:.2f}")
                print(f"   原始尺度MAE: {final_metrics['mae_original']:.2f}")
            print(f"   训练时间: {training_time/60:.1f} 分钟")
            
            return result
            
        except Exception as e:
            print(f"❌ Band {target_band} 训练失败: {e}")
            import traceback
            traceback.print_exc()
            return None
    
    def save_fine_tuning_results(self, results, failed_bands, total_time):
        """保存Fine-tuning结果"""
        final_results = {
            'source_strategy': self.source_strategy,
            'output_strategy': self.output_strategy,
            'timestamp': datetime.now().isoformat(),
            'total_time_hours': total_time / 3600,
            'successful_bands': len(results),
            'failed_bands': len(failed_bands),
            'results': results,
            'failed_band_list': failed_bands
        }
        
        results_file = os.path.join(self.output_dir, "fine_tuning_results.json")
        with open(results_file, 'w') as f:
            json.dump(final_results, f, indent=2, default=str)
        
        print(f"💾 结果已保存: {results_file}")

if __name__ == "__main__":
    main()
