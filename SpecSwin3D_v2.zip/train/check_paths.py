import os
import sys
import glob

def print_status(name, path, is_dir=True, required=True):
    """辅助函数：打印路径检查结果"""
    if path is None:
        print(f"❌ {name}: 未设置 (None)")
        return False
        
    exists = os.path.isdir(path) if is_dir else os.path.isfile(path)
    
    if exists:
        print(f"✅ {name}: {path}")
        # 如果是文件夹，打印里面有多少文件
        if is_dir:
            try:
                files = os.listdir(path)
                count = len(files)
                print(f"   └── 包含 {count} 个文件/文件夹")
                if count > 0:
                    # 只打印前3个文件作为示例
                    print(f"   └── 示例: {files[:3]}...")
            except:
                pass
    else:
        if required:
            print(f"❌ {name}: 不存在! \n   --> 路径: {path}")
        else:
            print(f"⚠️ {name}: 不存在 (可选)")
            
    return exists

def main():
    print("="*60)
    print("🔍 Swin-UNETR 项目环境与路径自检工具")
    print("="*60)

    # 1. 确定当前位置
    current_file = os.path.abspath(__file__)
    train_dir = os.path.dirname(current_file)
    project_root = os.path.dirname(train_dir)
    
    print(f"📂 当前脚本位置: {current_file}")
    print(f"📂 推导的项目根目录: {project_root}")
    print(f"🖥️  操作系统 (os.name): {os.name}")
    
    # 添加根目录到环境变量，以便导入 config
    sys.path.append(project_root)
    print("-" * 60)

    # 2. 模拟 train_swin_unetr_16_new.py 的路径逻辑
    print("🔄 正在模拟训练脚本的路径配置逻辑...")
    
    # 尝试导入 config
    try:
        from config import BASE_DIR, CHECKPOINT_DIR
        print(f"ℹ️  Config 原始 BASE_DIR: {BASE_DIR}")
        print(f"ℹ️  Config 原始 CHECKPOINT_DIR: {CHECKPOINT_DIR}")
    except ImportError:
        print("❌ 无法导入 config.py，请检查根目录下是否有 config.py")
        BASE_DIR = None
        CHECKPOINT_DIR = None

    # 应用修正逻辑 (核心部分)
    final_base_dir = BASE_DIR
    final_checkpoint_dir = CHECKPOINT_DIR

    if os.name == 'posix':  # Colab / Linux
        print("🐧 检测到 Linux/Colab 环境，应用强制修正...")
        final_checkpoint_dir = os.path.join(project_root, "checkpoints")
        final_base_dir = os.path.join(project_root, "dataset")
    elif os.name == 'nt':   # Windows
        print("🪟 检测到 Windows 环境...")
        if CHECKPOINT_DIR:
            drive, _ = os.path.splitdrive(CHECKPOINT_DIR)
            if drive and not os.path.exists(drive):
                print(f"⚠️  驱动器 {drive} 不存在，切换到相对路径...")
                final_checkpoint_dir = os.path.join(project_root, "checkpoints")
                final_base_dir = os.path.join(project_root, "dataset")

    print(f"🎯 最终使用的 BASE_DIR: {final_base_dir}")
    print(f"🎯 最终使用的 CHECKPOINT_DIR: {final_checkpoint_dir}")
    print("-" * 60)

    # 3. 检查关键目录和文件
    print("🔍 开始检查关键文件...")
    
    all_passed = True

    # 检查 Dataset 根目录
    if not print_status("Dataset 目录", final_base_dir): all_passed = False

    # 检查 Input (Raw) - 对应 --data_type raw
    input_raw_dir = os.path.join(final_base_dir, "input") if final_base_dir else None
    if not print_status("Input (Raw) 目录", input_raw_dir): 
        print("   ⚠️  注意：如果你使用 --data_type raw，这个目录是必须的")
        all_passed = False

    # 检查 Label
    label_dir = os.path.join(final_base_dir, "label") if final_base_dir else None
    if not print_status("Label 目录", label_dir): all_passed = False

    # 检查 PCA Stats - 对应 --use_anchor
    pca_path = os.path.join(final_base_dir, "pca_stats.pt") if final_base_dir else None
    if not print_status("PCA 统计文件", pca_path, is_dir=False): 
        print("   ⚠️  注意：如果你使用 --use_anchor，这个文件是必须的")
        all_passed = False

    # 检查 Checkpoints (可选，会自动创建)
    print_status("Checkpoints 目录", final_checkpoint_dir, required=False)

    print("-" * 60)

    # 4. 检查 Python 模块导入
    print("🐍 检查模块导入...")
    
    try:
        from models.swin_unetr_local import SwinUNETR_Local
        print("✅ 成功导入 models.swin_unetr_local")
    except ImportError as e:
        print(f"❌ 导入 models 失败: {e}")
        all_passed = False
    except Exception as e:
        print(f"❌ 导入 models 时发生未知错误: {e}")
        all_passed = False

    try:
        from denormalize_utils import denormalize_prediction
        print("✅ 成功导入 denormalize_utils")
    except ImportError as e:
        print(f"❌ 导入 denormalize_utils 失败: {e}")
        all_passed = False

    try:
        from losses import AnchorConsistencyLoss
        print("✅ 成功导入 losses")
    except ImportError as e:
        print(f"❌ 导入 losses 失败: {e}")
        all_passed = False

    print("="*60)
    if all_passed:
        print("🎉🎉🎉 所有检查通过！环境配置看起来是正确的。")
        print("🚀 你可以运行训练脚本了。")
    else:
        print("🛑 发现问题！请在运行训练前修复上述标记为 ❌ 的项。")
    # filepath: c:\Users\22125\Desktop\Swin-UNETR-Clean\train\check_paths.py
import os
import sys
import glob

def print_status(name, path, is_dir=True, required=True):
    """辅助函数：打印路径检查结果"""
    if path is None:
        print(f"❌ {name}: 未设置 (None)")
        return False
        
    exists = os.path.isdir(path) if is_dir else os.path.isfile(path)
    
    if exists:
        print(f"✅ {name}: {path}")
        # 如果是文件夹，打印里面有多少文件
        if is_dir:
            try:
                files = os.listdir(path)
                count = len(files)
                print(f"   └── 包含 {count} 个文件/文件夹")
                if count > 0:
                    # 只打印前3个文件作为示例
                    print(f"   └── 示例: {files[:3]}...")
            except:
                pass
    else:
        if required:
            print(f"❌ {name}: 不存在! \n   --> 路径: {path}")
        else:
            print(f"⚠️ {name}: 不存在 (可选)")
            
    return exists

def main():
    print("="*60)
    print("🔍 Swin-UNETR 项目环境与路径自检工具")
    print("="*60)

    # 1. 确定当前位置
    current_file = os.path.abspath(__file__)
    train_dir = os.path.dirname(current_file)
    project_root = os.path.dirname(train_dir)
    
    print(f"📂 当前脚本位置: {current_file}")
    print(f"📂 推导的项目根目录: {project_root}")
    print(f"🖥️  操作系统 (os.name): {os.name}")
    
    # 添加根目录到环境变量，以便导入 config
    sys.path.append(project_root)
    print("-" * 60)

    # 2. 模拟 train_swin_unetr_16_new.py 的路径逻辑
    print("🔄 正在模拟训练脚本的路径配置逻辑...")
    
    # 尝试导入 config
    try:
        from config import BASE_DIR, CHECKPOINT_DIR
        print(f"ℹ️  Config 原始 BASE_DIR: {BASE_DIR}")
        print(f"ℹ️  Config 原始 CHECKPOINT_DIR: {CHECKPOINT_DIR}")
    except ImportError:
        print("❌ 无法导入 config.py，请检查根目录下是否有 config.py")
        BASE_DIR = None
        CHECKPOINT_DIR = None

    # 应用修正逻辑 (核心部分)
    final_base_dir = BASE_DIR
    final_checkpoint_dir = CHECKPOINT_DIR

    if os.name == 'posix':  # Colab / Linux
        print("🐧 检测到 Linux/Colab 环境，应用强制修正...")
        final_checkpoint_dir = os.path.join(project_root, "checkpoints")
        final_base_dir = os.path.join(project_root, "dataset")
    elif os.name == 'nt':   # Windows
        print("🪟 检测到 Windows 环境...")
        if CHECKPOINT_DIR:
            drive, _ = os.path.splitdrive(CHECKPOINT_DIR)
            if drive and not os.path.exists(drive):
                print(f"⚠️  驱动器 {drive} 不存在，切换到相对路径...")
                final_checkpoint_dir = os.path.join(project_root, "checkpoints")
                final_base_dir = os.path.join(project_root, "dataset")

    print(f"🎯 最终使用的 BASE_DIR: {final_base_dir}")
    print(f"🎯 最终使用的 CHECKPOINT_DIR: {final_checkpoint_dir}")
    print("-" * 60)

    # 3. 检查关键目录和文件
    print("🔍 开始检查关键文件...")
    
    all_passed = True

    # 检查 Dataset 根目录
    if not print_status("Dataset 目录", final_base_dir): all_passed = False

    # 检查 Input (Raw) - 对应 --data_type raw
    input_raw_dir = os.path.join(final_base_dir, "input") if final_base_dir else None
    if not print_status("Input (Raw) 目录", input_raw_dir): 
        print("   ⚠️  注意：如果你使用 --data_type raw，这个目录是必须的")
        all_passed = False

    # 检查 Label
    label_dir = os.path.join(final_base_dir, "label") if final_base_dir else None
    if not print_status("Label 目录", label_dir): all_passed = False

    # 检查 PCA Stats - 对应 --use_anchor
    pca_path = os.path.join(final_base_dir, "pca_stats.pt") if final_base_dir else None
    if not print_status("PCA 统计文件", pca_path, is_dir=False): 
        print("   ⚠️  注意：如果你使用 --use_anchor，这个文件是必须的")
        all_passed = False

    # 检查 Checkpoints (可选，会自动创建)
    print_status("Checkpoints 目录", final_checkpoint_dir, required=False)

    print("-" * 60)

    # 4. 检查 Python 模块导入
    print("🐍 检查模块导入...")
    
    try:
        from models.swin_unetr_local import SwinUNETR_Local
        print("✅ 成功导入 models.swin_unetr_local")
    except ImportError as e:
        print(f"❌ 导入 models 失败: {e}")
        all_passed = False
    except Exception as e:
        print(f"❌ 导入 models 时发生未知错误: {e}")
        all_passed = False

    try:
        from denormalize_utils import denormalize_prediction
        print("✅ 成功导入 denormalize_utils")
    except ImportError as e:
        print(f"❌ 导入 denormalize_utils 失败: {e}")
        all_passed = False

    try:
        from losses import AnchorConsistencyLoss
        print("✅ 成功导入 losses")
    except ImportError as e:
        print(f"❌ 导入 losses 失败: {e}")
        all_passed = False

    print("="*60)
    if all_passed:
        print("🎉🎉🎉 所有检查通过！环境配置看起来是正确的。")
        print("🚀 你可以运行训练脚本了。")
    else:
        print("🛑 发现问题！请在运行训练前修复上述标记为 ❌ 的项。")
    print("="*60)

if __name__ == "__main__":
    main()