﻿import sys
import os
import json
import contextlib  # ✅ 添加这个导入
from datetime import datetime

# Add parent directory to path以导入config
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from config import BASE_DIR, CHECKPOINT_DIR

import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import Dataset, DataLoader
import glob
from tqdm import tqdm
import numpy as np
from torch.utils.tensorboard import SummaryWriter
import argparse
from sklearn.cluster import KMeans
from sklearn.metrics import pairwise_distances
from denormalize_utils import denormalize_prediction
from losses import AnchorConsistencyLoss, SAMLoss

# Import model
# from monai.networks.nets import SwinUNETR
from models.swin_unetr_local import SwinUNETR_Local as SwinUNETR

class SwinUNETR_SingleBand(nn.Module):
    """单波段光谱重建模型"""
    def __init__(self, in_channels=16, img_size=(128, 128), spatial_dims=2, use_anchor=False, patch_size=2, downsample="combinatorial"):  # 🔥 添加 patch_size 和 downsample
        super().__init__()
        self.use_anchor = use_anchor
        self.model = SwinUNETR(
            img_size=img_size,
            in_channels=in_channels,
            # out_channels=1, # Removed because SwinUNETR_Local does not accept it and hardcodes it to 1
            feature_size=48,
            spatial_dims=spatial_dims,    # 🔥 使用参数
            use_checkpoint=False,
            use_anchor_head=use_anchor,   # 🔥 传递参数
            anchor_k=10,
            patch_size=patch_size,        # 🔥 传递 patch_size
            downsample=downsample         # 🔥 传递 downsample
        )
    
    def forward(self, x):
        if self.use_anchor:
            out = self.model(x) # Returns (logits, anchor_out)
            logits, anchor_out = out
        else:
            logits = self.model(x) # Returns logits
            anchor_out = None
            
        # 🔥 如果是3D模式且输出深度>1，我们需要处理它
        # 假设我们想要预测单个波段，我们可以取平均或者切片
        # 对于Combinatorial模式，输出深度应该是1 (Map 4: 5->1)
        # 但如果不是，我们强制压缩
        if logits.dim() == 5 and logits.shape[2] > 1:
             # (B, C, D, H, W) -> (B, C, 1, H, W)
             # 这里简单取平均，或者你可以选择特定的切片
             logits = logits.mean(dim=2, keepdim=True)
             
        if self.use_anchor:
            return logits, anchor_out
        return logits

class SingleBandDataset(Dataset):
    """单波段光谱重建数据集"""
    def __init__(self, input_dir, label_dir, target_band_idx, use_3d=False, return_anchor=False):  # 🔥 添加use_3d和return_anchor参数
        self.input_dir = input_dir
        self.label_dir = label_dir
        self.target_band_idx = target_band_idx
        self.return_anchor = return_anchor
        
        # Load PCA stats if needed
        self.pca_components = None
        self.pca_mean = None
        if self.return_anchor:
            # Try multiple locations for pca_stats.pt
            possible_pca_paths = [
                os.path.join(BASE_DIR, 'pca_stats.pt'),
                os.path.join(os.path.dirname(BASE_DIR), 'pca_stats.pt'), # Parent of dataset dir
                os.path.join(os.getcwd(), 'pca_stats.pt') # Current working directory
            ]
            
            pca_path = None
            for path in possible_pca_paths:
                if os.path.exists(path):
                    pca_path = path
                    break
            
            if pca_path:
                pca_stats = torch.load(pca_path, map_location='cpu')
                self.pca_components = pca_stats['components'].float() # (219, 10)
                self.pca_mean = pca_stats['mean'].float()             # (219,)
                print(f"✅ 已加载PCA统计数据: {pca_path}")
            else:
                print(f"⚠️ 未找到PCA统计数据，尝试过以下路径:")
                for path in possible_pca_paths:
                    print(f"   - {path}")
                print(f"⚠️ 将无法计算Anchor Loss")
                self.return_anchor = False
        
        # ✅ 添加：定义输入波段（与input-label.py保持一致）
        self.input_bands = [30, 20, 9, 40, 52]
        
        # ✅ 添加：检查目标波段是否为输入波段
        if target_band_idx in self.input_bands:
            raise ValueError(f"目标波段 {target_band_idx} 是输入波段，不能作为重建目标！输入波段: {self.input_bands}")
        
        self.input_files = sorted(glob.glob(os.path.join(input_dir, "*.pt")))
        self.label_files = sorted(glob.glob(os.path.join(label_dir, "*.pt")))
        
        assert len(self.input_files) == len(self.label_files), \
            f"输入文件数({len(self.input_files)})与标签文件数({len(self.label_files)})不匹配"
        
        # 获取归一化参数
        sample_label = torch.load(self.label_files[0], map_location='cpu')
        if isinstance(sample_label, dict) and 'norm_params' in sample_label:
            label_band_indices = sample_label['band_indices']
            if target_band_idx in label_band_indices:
                band_pos_in_label = label_band_indices.index(target_band_idx)
                self.norm_params = sample_label['norm_params'][band_pos_in_label]
            else:
                self.norm_params = None
        else:
            self.norm_params = None
        
        print(f"📊 单波段数据集: {len(self.input_files)} 样本, 目标波段: {target_band_idx}")
        
        self.use_3d = use_3d
    
    def get_norm_params(self):
        return self.norm_params
    
    def __len__(self):
        return len(self.input_files)
    
    def __getitem__(self, idx):  # 🔥 正确缩进到类内部
        input_data = torch.load(self.input_files[idx], map_location='cpu')
        label_data = torch.load(self.label_files[idx], map_location='cpu')
        
        input_tensor = input_data['input'] if isinstance(input_data, dict) else input_data
        label_tensor = label_data['label'] if isinstance(label_data, dict) else label_data
        
        input_tensor = input_tensor.float()
        label_tensor = label_tensor.float()
        
        # 🔥 根据模式处理输入数据
        if self.use_3d:
            # 3D模式: (C, 128, 128) -> (1, D, 128, 128)
            if input_tensor.dim() == 3:
                # input_tensor: (C, H, W)
                if input_tensor.shape[0] == 5:
                    # 5通道 -> 5深度 (Combinatorial Mode)
                    # 我们需要 (1, 5, 128, 128)
                    input_tensor = input_tensor.unsqueeze(0)
                elif input_tensor.shape[0] == 16:
                    # 16通道 -> 32深度 (Padding Mode)
                    input_tensor = input_tensor.permute(1, 2, 0)  # (128, 128, 16)
                    input_tensor = torch.cat([input_tensor, input_tensor], dim=2)  # (128, 128, 32)
                    input_tensor = input_tensor.unsqueeze(0).permute(0, 3, 1, 2) # (1, 32, 128, 128)
                
                # print(f"🔍 [DEBUG] 3D输入数据形状: {input_tensor.shape}")
        # else: 2D模式保持 (C, 128, 128)
        
        # ✅ 先定义target_band（保持原有逻辑）
        if isinstance(label_data, dict) and 'band_indices' in label_data:
            label_band_indices = label_data['band_indices']
            
            if self.target_band_idx in label_band_indices:
                band_pos_in_label = label_band_indices.index(self.target_band_idx)
                if band_pos_in_label < label_tensor.shape[0]:
                    target_band = label_tensor[band_pos_in_label:band_pos_in_label+1]
                else:
                    raise ValueError(f"目标波段 {self.target_band_idx} 的位置 {band_pos_in_label} 超出张量范围 {label_tensor.shape[0]}")
            else:
                # ✅ 更清晰的错误信息
                raise ValueError(f"目标波段 {self.target_band_idx} 不在标签数据中！可能是输入波段 {self.input_bands} 之一")
        else:
            # 没有band_indices的情况下直接索引
            if self.target_band_idx < label_tensor.shape[0]:
                target_band = label_tensor[self.target_band_idx:self.target_band_idx+1]
            else:
                raise ValueError(f"目标波段 {self.target_band_idx} 超出张量范围 {label_tensor.shape[0]}")

        # 🔥 现在处理target_band的3D转换（移到定义之后）
        if self.use_3d:
            # 3D模式: 确保是 (1, 128, 128, 32) 格式
            if target_band.dim() == 2:
                target_band = target_band.unsqueeze(0).unsqueeze(0)  # -> (1, 1, 128, 128)
            elif target_band.dim() == 3:
                target_band = target_band.unsqueeze(0)               # -> (1, 1, 128, 128)
            
            # 如果是16通道模式，我们需要重复target以匹配输出深度32
            # 但如果是5通道Combinatorial模式，输出深度是1，所以不需要重复
            if input_tensor.shape[1] == 32: # 检查深度维度
                 target_band = target_band.repeat(1, 32, 1, 1) # (1, 32, 128, 128)
            
            # print(f"🔍 [DEBUG] 3D目标数据形状: {target_band.shape}")
        # else: 2D模式保持 (1, 128, 128)
        
        if self.return_anchor and self.pca_components is not None:
            # Calculate PCA coefficients for the full label
            # label_tensor: (219, H, W)
            # Flatten spatial dims: (219, H*W)
            # Transpose: (H*W, 219)
            # Center: (X - mean)
            # Project: (X - mean) @ Components (219, 10) -> (H*W, 10)
            # Transpose back: (10, H*W) -> (10, H, W)
            
            # Ensure label is full spectrum (219 bands)
            if label_tensor.shape[0] == 219:
                flat_label = label_tensor.view(219, -1).T # (N, 219)
                centered = flat_label - self.pca_mean.to(flat_label.device)
                coeffs = torch.matmul(centered, self.pca_components.to(flat_label.device)) # (N, 10)
                
                # Reshape back to (10, H, W)
                pca_coeffs = coeffs.T.view(10, label_tensor.shape[1], label_tensor.shape[2])
                
                # If 3D, we might need to adjust, but Anchor Head usually works on 2D spatial or 3D volume.
                # The Anchor Head in SwinUNETR is:
                # self.avg_pool = nn.AdaptiveAvgPool3d(1) if spatial_dims == 3 else nn.AdaptiveAvgPool2d(1)
                # It pools the bottleneck features to (B, C, 1, 1, 1) or (B, C, 1, 1)
                # Then flattens and projects to (B, 10).
                # So the target should be the GLOBAL PCA coefficients for the whole image?
                # Or pixel-wise?
                # The implementation of SpectralAnchorHead:
                # x = self.avg_pool(x) -> Global Average Pooling
                # So it predicts ONE vector of coefficients per image.
                # So we should Average Pool the coefficients here too.
                
                pca_coeffs_global = pca_coeffs.mean(dim=(1, 2)) # (10,)
                
                return input_tensor, target_band, pca_coeffs_global
            else:
                # Fallback if label is not 219 bands (e.g. already sliced?)
                # Should not happen based on logic
                return input_tensor, target_band, torch.zeros(10)

        return input_tensor, target_band

def create_single_band_loaders(target_band_idx, batch_size=16, num_workers=8, data_type='with_indices', use_3d=False, return_anchor=False):  # 🔥 添加use_3d和return_anchor参数
    """创建数据加载器 - 支持选择数据类型"""
    
    # 🔥 修改：根据数据类型选择目录名
    if data_type == 'with_indices':
        input_dir_name = "input_restacked_16_with_indices"
        data_description = "植被指数增强数据"
    elif data_type == 'repeated':
        input_dir_name = "input_restacked_16_repeated"
        data_description = "重复模式16通道数据 [0,0,0,0,1,1,1,2,2,2,3,3,3,4,4,4]"
    elif data_type == 'raw':
        input_dir_name = "input"
        data_description = "原始5通道数据"
    else:  # original
        input_dir_name = "input_restacked_16"
        data_description = "原始16通道数据"
    
    # 🔥 修改：自动检测操作系统并使用正确路径
    possible_base_dirs = []
    
    # 1. 优先使用config中配置的BASE_DIR
    if BASE_DIR:
        possible_base_dirs.append(BASE_DIR)
        
    # 2. 尝试相对于当前脚本的路径
    script_dir = os.path.dirname(os.path.abspath(__file__))
    project_root = os.path.dirname(script_dir)
    possible_base_dirs.append(os.path.join(project_root, "dataset"))
    
    if os.name == 'nt':  # Windows
        # possible_base_dirs.append("D:/wisc/SpecTran/codes/Swin-Unetr/Swin-UNETR-Clean/dataset")
        pass
    else:  # Linux
        # possible_base_dirs.append("/home/ai4sg/tang/Swin-UNETR-Clean/dataset")
        # possible_base_dirs.append("/home/ai4sg/tang/SpecSwin3D/Swin-UNETR-Clean/dataset")
        pass
    
    input_dir = None
    label_dir = None
    
    # 🔥 根据选择的数据类型查找目录
    for base_dir in possible_base_dirs:
        test_input_dir = os.path.join(base_dir, input_dir_name)
        test_label_dir = os.path.join(base_dir, "label")
        
        print(f"🔍 检查{data_description}路径: {test_input_dir}")
        if os.path.exists(test_input_dir) and os.path.exists(test_label_dir):
            input_dir = test_input_dir
            label_dir = test_label_dir
            print(f"✅ 找到{data_description}目录: {base_dir}")
            break
        else:
            print(f"❌ {data_description}目录不存在: {base_dir}")
    
    # 🔥 如果找不到指定类型数据，直接报错（不再fallback）
    if input_dir is None or label_dir is None:
        print(f"❌ 未找到{data_description}目录！")
        print(f"📁 需要存在以下目录:")
        for base_dir in possible_base_dirs:
            print(f"   - {base_dir}/{input_dir_name}")
            print(f"   - {base_dir}/label")
        
        if data_type == 'with_indices':
            print(f"💡 提示: 请确保已运行数据预处理脚本生成植被指数增强数据")
        else:
            print(f"💡 提示: 请确保原始16通道数据存在")
        
        raise FileNotFoundError(f"{data_description}目录不存在！需要 {input_dir_name} 目录。BASE_DIR: {BASE_DIR}")
    
    print(f"📁 使用{data_description}: {input_dir}")
    print(f"📁 使用标签数据: {label_dir}")
    
    # 检查数据文件数量
    input_files = len(glob.glob(os.path.join(input_dir, "*.pt")))
    label_files = len(glob.glob(os.path.join(label_dir, "*.pt")))
    print(f"📊 发现{data_description}文件: 输入={input_files}, 标签={label_files}")
    
    if input_files == 0 or label_files == 0:
        raise FileNotFoundError(f"{data_description}文件不存在！输入文件: {input_files}, 标签文件: {label_files}")
    
    full_dataset = SingleBandDataset(input_dir, label_dir, target_band_idx, use_3d=use_3d, return_anchor=return_anchor)  # 🔥 传递use_3d和return_anchor
    
    dataset_size = len(full_dataset)
    train_size = int(0.7 * dataset_size)
    val_size = int(0.15 * dataset_size)
    test_size = dataset_size - train_size - val_size
    
    train_dataset, val_dataset, test_dataset = torch.utils.data.random_split(
        full_dataset, [train_size, val_size, test_size],
        generator=torch.Generator().manual_seed(42)
    )
    
    # Windows上使用少量worker
    num_workers = 0 if os.name == 'nt' else 8
    pin_memory = False
    
    train_loader = DataLoader(train_dataset, batch_size=batch_size, shuffle=True, 
                            num_workers=num_workers, pin_memory=pin_memory, drop_last=True)
    val_loader = DataLoader(val_dataset, batch_size=batch_size*2, shuffle=False,
                          num_workers=num_workers, pin_memory=pin_memory)
    test_loader = DataLoader(test_dataset, batch_size=batch_size*2, shuffle=False,
                           num_workers=num_workers, pin_memory=pin_memory)
    
    return train_loader, val_loader, test_loader

def get_spectral_similarity(band1, band2):
    """计算光谱相似性"""
    wavelength_groups = {
        'visible': (0, 79),
        'nir': (80, 159), 
        'swir': (160, 218)  # ✅ 修改为218
    }
    
    def get_group(band):  # ✅ 修改：参数名改为band
        for group, (start, end) in wavelength_groups.items():
            if start <= band <= end:  # ✅ 现在参数名一致了
                return group
        return 'unknown'
    
    group1 = get_group(band1)
    group2 = get_group(band2)
    
    distance = abs(band1 - band2)
    
    if group1 == group2:
        similarity = 1.0 / (1.0 + distance * 0.1)
    else:
        similarity = 1.0 / (1.0 + distance * 0.2)
    
    return similarity

def find_best_pretrained_model(target_band_idx, trained_bands, checkpoint_dir, current_strategy, use_pretrained=False, pretrained_strategy=None):
    """找到最佳预训练模型 - 支持灵活的查找策略"""
    
    # 🔥 如果不使用预训练，直接返回None
    if not use_pretrained:
        print(f"🆕 波段 {target_band_idx} 从零开始训练（禁用预训练模型）")
        return None
        
    if not trained_bands:
        print(f"🆕 波段 {target_band_idx} 从零开始训练（无可用的预训练模型）")
        return None
    
    # 计算相似性
    similarities = []
    for trained_band in trained_bands:
        similarity = get_spectral_similarity(target_band_idx, trained_band)
        similarities.append((trained_band, similarity))
    
    similarities.sort(key=lambda x: x[1], reverse=True)
    best_band = similarities[0][0]
    
    # 🎯 根据参数决定查找策略
    search_strategies = []
    
    if pretrained_strategy:
        # 指定了特定策略
        search_strategies = [pretrained_strategy]
        print(f"🔍 在指定策略 {pretrained_strategy} 中查找预训练模型...")
    else:
        # 查找顺序：当前策略 -> 所有其他策略
        search_strategies = [current_strategy]
        
        # 添加其他所有策略
        try:
            all_strategies = [d for d in os.listdir(checkpoint_dir) 
                            if os.path.isdir(os.path.join(checkpoint_dir, d)) and d != current_strategy]
            search_strategies.extend(all_strategies)
        except:
            pass
        
        print(f"🔍 查找预训练模型顺序: {search_strategies}")
    
    # 按顺序查找最佳预训练模型
    for strategy in search_strategies:
        strategy_models_dir = os.path.join(checkpoint_dir, strategy, "models")
        best_model_path = os.path.join(strategy_models_dir, f"band_{best_band:03d}_best_model.pth")
        
        if os.path.exists(best_model_path):
            print(f"🔗 波段 {target_band_idx} 使用波段 {best_band} 的预训练模型")
            print(f"   相似性: {similarities[0][1]:.3f}")
            print(f"   来源策略: {strategy}")
            print(f"   模型路径: {best_model_path}")
            return best_model_path
    
    print(f"🆕 波段 {target_band_idx} 从零开始训练（未找到合适的预训练模型）")
    return None

def get_cascade_training_params(target_band_idx, pretrained_available, cascade_level):
    """获取训练参数"""
    base_epochs = 80
    base_lr = 2e-4
    
    if not pretrained_available:
        return {
            'epochs': base_epochs,
            'lr': base_lr,
            'weight_decay': 5e-6,
            'warmup_epochs': 10,
            'gradient_clip': 1.0,
            'accumulation_steps': 2
        }
    else:
        lr_decay = 0.7 ** cascade_level
        epoch_decay = max(0.5, 0.9 ** cascade_level)
        
        return {
            'epochs': max(40, int(base_epochs * epoch_decay)),
            'lr': base_lr * lr_decay,
            'weight_decay': 5e-6,
            'warmup_epochs': 5,
            'gradient_clip': 1.0,
            'accumulation_steps': 1
        }

def train_single_band_model(target_band_idx, cascade_level, batch_size, device, 
                           pretrained_model_path, strategy_dir, writer, data_type='with_indices', use_3d=False, use_anchor=False):  # 🔥 添加use_anchor参数
    
    print(f"\n🎯 训练 Band {target_band_idx} (Level {cascade_level}) - {'3D' if use_3d else '2D'} 模式 - Anchor: {use_anchor}")
    
    # ✅ 轻量级CUDA清理
    if device.type == 'cuda':
        torch.cuda.empty_cache()  # 只清理缓存，不同步
    
    # 🔥 传递data_type和return_anchor参数
    train_loader, val_loader, test_loader = create_single_band_loaders(target_band_idx, batch_size, data_type=data_type, use_3d=use_3d, return_anchor=use_anchor)
    
    # 🔥 Check if dataset actually enabled anchor (it might disable it if pca_stats.pt is missing)
    # Handle Subset (from random_split)
    actual_dataset = train_loader.dataset
    if hasattr(actual_dataset, 'dataset'): # It's a Subset
        actual_dataset = actual_dataset.dataset
        
    if use_anchor and hasattr(actual_dataset, 'return_anchor'):
         if not actual_dataset.return_anchor:
             print("⚠️ Dataset disabled anchor return (missing pca_stats.pt). Disabling use_anchor for training.")
             use_anchor = False

    # 获取训练参数
    train_params = get_cascade_training_params(
        target_band_idx, pretrained_model_path is not None, cascade_level
    )
    
    # 🔥 根据模式创建模型
    if use_3d:
        # If raw, use depth 5
        depth = 5 if data_type == 'raw' else 32
        
        # 🔥 Determine patch_size and downsample
        if data_type == 'raw':
            patch_size = (1, 2, 2)
            downsample = "combinatorial"
        else:
            patch_size = 2 # (2, 2, 2)
            downsample = "merging" # or "mergingv2"
            
        model = SwinUNETR_SingleBand(
            in_channels=1,           # 3D模式：1个输入通道
            img_size=(depth, 128, 128), # 🔥 动态深度
            spatial_dims=3,
            use_anchor=use_anchor,
            patch_size=patch_size,    # 🔥 传递 patch_size
            downsample=downsample     # 🔥 传递 downsample
        ).to(device)
        print(f"🔍 [DEBUG] 3D模型创建成功: img_size=({depth}, 128, 128), in_channels=1, patch_size={patch_size}, downsample={downsample}")
    else:
        # 🔥 自动确定输入通道数
        in_channels = 5 if data_type == 'raw' else 16
        model = SwinUNETR_SingleBand(
            in_channels=in_channels, # 2D模式：根据数据类型决定通道数
            img_size=(128, 128),     # 2D尺寸
            spatial_dims=2,
            use_anchor=use_anchor,
            patch_size=2,            # 2D default
            downsample="mergingv2"   # 2D default
        ).to(device)
        print(f"🔍 [DEBUG] 2D模型创建成功: img_size=(128, 128), in_channels={in_channels}")
    
    # 加载预训练权重
    if pretrained_model_path and os.path.exists(pretrained_model_path):
        print(f"🔄 加载预训练权重: {pretrained_model_path}")
        try:
            checkpoint = torch.load(pretrained_model_path, map_location=device)
            model.load_state_dict(checkpoint['model_state_dict'])
            print("✅ 预训练权重加载成功")
        except Exception as e:
            print(f"⚠️ 预训练权重加载失败: {e}")
    
    # 训练设置
    criterion = nn.MSELoss()
    # Anchor Loss: MSE + SAM on PCA coefficients
    anchor_mse_criterion = nn.MSELoss() if use_anchor else None
    anchor_sam_criterion = SAMLoss(spectral_dim=1) if use_anchor else None
    
    optimizer = optim.AdamW(model.parameters(), lr=train_params['lr'], 
                           weight_decay=train_params['weight_decay'])
    scaler = None  # torch.cuda.amp.GradScaler() if device.type == 'cuda' else None
    
    # 学习率调度
    warmup_scheduler = optim.lr_scheduler.LinearLR(
        optimizer, start_factor=0.05, total_iters=train_params['warmup_epochs']
    )
    main_scheduler = optim.lr_scheduler.OneCycleLR(
        optimizer, max_lr=train_params['lr'] * 2,
        total_steps=train_params['epochs'] - train_params['warmup_epochs'],
        pct_start=0.3, anneal_strategy='cos'
    )
    
    # 训练循环
    best_val_loss = float('inf')
    # ✅ 修改：模型保存到策略专用目录
    best_model_path = os.path.join(strategy_dir, f"band_{target_band_idx:03d}_best_model.pth")
    
    print(f"📊 训练参数: Epochs={train_params['epochs']}, LR={train_params['lr']:.6f}")
    
    for epoch in range(1, train_params['epochs'] + 1):
        # 训练阶段
        model.train()
        train_loss = 0.0
        anchor_loss_sum = 0.0
        
        pbar = tqdm(train_loader, desc=f"🔥 Band {target_band_idx} L{cascade_level} Epoch {epoch}")
        
        for batch_idx, batch_data in enumerate(pbar):
            if use_anchor:
                inputs, targets, anchor_gt = batch_data
                anchor_gt = anchor_gt.to(device, non_blocking=True)
            else:
                inputs, targets = batch_data
                
            inputs = inputs.to(device, non_blocking=True)
            targets = targets.to(device, non_blocking=True)
            
            # 🔍 添加调试信息（仅第一个batch）
            if epoch == 1 and batch_idx == 0:
                print(f"🔍 [DEBUG] 训练数据形状: inputs={inputs.shape}, targets={targets.shape}")
            
            with torch.cuda.amp.autocast() if scaler else contextlib.nullcontext():
                if use_anchor:
                    outputs, anchor_pred = model(inputs)
                    main_loss = criterion(outputs, targets)
                    
                    # Anchor Loss
                    mse_loss = anchor_mse_criterion(anchor_pred, anchor_gt)
                    sam_loss = anchor_sam_criterion(anchor_pred, anchor_gt)
                    
                    # Weights (can be tuned)
                    lambda_mse = 0.1
                    lambda_sam = 0.1
                    
                    a_loss = lambda_mse * mse_loss + lambda_sam * sam_loss
                    loss = main_loss + a_loss
                    anchor_loss_sum += a_loss.item()
                else:
                    outputs = model(inputs)
                    loss = criterion(outputs, targets)
                
                if 'accumulation_steps' in train_params:
                    loss = loss / train_params['accumulation_steps']
            
            if scaler:
                scaler.scale(loss).backward()
                if (batch_idx + 1) % train_params.get('accumulation_steps', 1) == 0:
                    if 'gradient_clip' in train_params:
                        scaler.unscale_(optimizer)
                        torch.nn.utils.clip_grad_norm_(model.parameters(), train_params['gradient_clip'])
                    scaler.step(optimizer)
                    scaler.update()
                    optimizer.zero_grad()
            else:
                loss.backward()
                if (batch_idx + 1) % train_params.get('accumulation_steps', 1) == 0:
                    if 'gradient_clip' in train_params:
                        torch.nn.utils.clip_grad_norm_(model.parameters(), train_params['gradient_clip'])
                    optimizer.step()
                    optimizer.zero_grad()
            
            train_loss += loss.item() * train_params.get('accumulation_steps', 1)
            
            postfix = {'Loss': f'{loss.item():.6f}', 'LR': f'{optimizer.param_groups[0]["lr"]:.7f}'}
            if use_anchor:
                postfix['ALoss'] = f'{a_loss.item():.6f}'
            pbar.set_postfix(postfix)
        
        avg_train_loss = train_loss / len(train_loader)
        
        # 验证阶段
        model.eval()
        val_loss = 0.0
        with torch.no_grad():
            for batch_data in val_loader:
                if use_anchor:
                    inputs, targets, anchor_gt = batch_data
                    anchor_gt = anchor_gt.to(device)
                else:
                    inputs, targets = batch_data
                    
                inputs = inputs.to(device)
                targets = targets.to(device)
                
                if use_anchor:
                    outputs, anchor_pred = model(inputs)
                    main_loss = criterion(outputs, targets)
                    
                    mse_loss = anchor_mse_criterion(anchor_pred, anchor_gt)
                    sam_loss = anchor_sam_criterion(anchor_pred, anchor_gt)
                    
                    lambda_mse = 0.1
                    lambda_sam = 0.1
                    
                    a_loss = lambda_mse * mse_loss + lambda_sam * sam_loss
                    loss = main_loss + a_loss
                else:
                    outputs = model(inputs)
                    loss = criterion(outputs, targets)
                    
                val_loss += loss.item()
        
        avg_val_loss = val_loss / len(val_loader)
        
        # 更新学习率
        if epoch <= train_params['warmup_epochs']:
            warmup_scheduler.step()
        else:
            main_scheduler.step()
        
        # 记录到TensorBoard
        global_step = cascade_level * 1000 + epoch  # 确保不同级别的步数不重叠
        writer.add_scalar(f'Loss/Train_Band_{target_band_idx}', avg_train_loss, global_step)
        writer.add_scalar(f'Loss/Val_Band_{target_band_idx}', avg_val_loss, global_step)
        writer.add_scalar(f'LR/Band_{target_band_idx}', optimizer.param_groups[0]['lr'], global_step)
        writer.add_scalar(f'CascadeLevel/Band_{target_band_idx}', cascade_level, global_step)
        
        print(f"📈 Epoch {epoch}/{train_params['epochs']}: Train={avg_train_loss:.6f}, Val={avg_val_loss:.6f}")
        
        # 保存最佳模型
        if avg_val_loss < best_val_loss:
            best_val_loss = avg_val_loss
            torch.save({
                'epoch': epoch,
                'model_state_dict': model.state_dict(),
                'optimizer_state_dict': optimizer.state_dict(),
                'val_loss': avg_val_loss,
                'target_band_idx': target_band_idx,
                'cascade_level': cascade_level,
                'train_params': train_params
            }, best_model_path)
    
    # 最终测试
    print(f"🧪 Band {target_band_idx} 最终测试...")
    if os.path.exists(best_model_path):
        checkpoint = torch.load(best_model_path, map_location=device)
        model.load_state_dict(checkpoint['model_state_dict'])
    
    # 获取归一化参数
    dataset = train_loader.dataset
    if hasattr(dataset, 'dataset'):
        norm_params = dataset.dataset.get_norm_params()
    else:
        norm_params = dataset.get_norm_params()
    
    model.eval()
    test_results = evaluate_model(model, test_loader, device, norm_params)
    
    print(f"📊 Band {target_band_idx} 测试结果:")
    print(f"   RMSE: {test_results['rmse']:.6f}")
    print(f"   MAE: {test_results['mae']:.6f}")
    if 'rmse_original' in test_results:
        print(f"   原始RMSE: {test_results['rmse_original']:.2f}")
        print(f"   原始MAE: {test_results['mae_original']:.2f}")
    
    return best_model_path, test_results

def evaluate_model(model, test_loader, device, norm_params):
    """评估模型性能"""
    criterion = nn.MSELoss()
    test_loss = 0.0
    test_mse = 0.0
    test_mae = 0.0
    test_rmse_original = 0.0
    test_mae_original = 0.0
    num_samples = 0
    
    with torch.no_grad():
        for inputs, targets in test_loader:
            inputs = inputs.to(device)
            targets = targets.to(device)
            outputs = model(inputs)
            
            test_loss += criterion(outputs, targets).item()
            test_mse += nn.MSELoss()(outputs, targets).item() * inputs.size(0)
            test_mae += nn.L1Loss()(outputs, targets).item() * inputs.size(0)
            
            if norm_params is not None:
                for b in range(outputs.shape[0]):
                    pred_denorm = denormalize_prediction(outputs[b, 0].cpu().numpy(), norm_params)
                    target_denorm = denormalize_prediction(targets[b, 0].cpu().numpy(), norm_params)
                    
                    rmse_orig = np.sqrt(np.mean((pred_denorm - target_denorm) ** 2))
                    mae_orig = np.mean(np.abs(pred_denorm - target_denorm))
                    
                    test_rmse_original += rmse_orig
                    test_mae_original += mae_orig
            
            num_samples += inputs.size(0)
    
    results = {
        'test_loss': test_loss / len(test_loader),
        'mse': test_mse / num_samples,
        'mae': test_mae / num_samples,
        'rmse': np.sqrt(test_mse / num_samples)
    }
    
    if norm_params is not None and num_samples > 0:
        results.update({
            'rmse_original': test_rmse_original / num_samples,
            'mae_original': test_mae_original / num_samples,
            'norm_range': [norm_params['p1'], norm_params['p99']]
        })
    
    return results

def load_custom_strategy_from_txt(txt_file):
    """从txt文件加载自定义策略"""
    strategy_data = {}
    strategy_name = "custom"
    
    with open(txt_file, 'r', encoding='utf-8') as f:
        lines = f.readlines()
    
    for line in lines:
        line = line.strip()
        if line.startswith('#') or not line:
            continue
        
        # 解析策略名称
        if line.startswith('strategy_name:'):
            strategy_name = line.split(':', 1)[1].strip()
        
        # 解析级别
        elif line.startswith('level_'):
            parts = line.split(':', 1)
            level = int(parts[0].split('_')[1])
            bands_str = parts[1].strip()
            # 解析波段列表 [1, 2, 3] 或 1,2,3
            if bands_str.startswith('[') and bands_str.endswith(']'):
                bands_str = bands_str[1:-1]
            bands = [int(x.strip()) for x in bands_str.split(',') if x.strip()]
            strategy_data[level] = bands
    
    return strategy_data, strategy_name

def design_cascade_strategy(strategy_type="physical", custom_txt_file=None):
    """设计级联策略 - physical和uniform硬编码，其他4个从txt加载"""
    
    print(f"🔍 [DEBUG] 进入design_cascade_strategy函数")
    print(f"🔍 [DEBUG] 参数: strategy_type='{strategy_type}', custom_txt_file={custom_txt_file}")
    
    try:
        print(f"🔍 开始解析策略类型: {strategy_type}")
        
        # 🔥 保留硬编码的策略
        if strategy_type == "physical":
            print("✅ 使用内置physical策略")
            result = {
                0: [0, 1, 2, 3, 4, 5, 6, 7, 8],
                1: [15, 25, 27],
                2: [48, 50, 54, 67, 81, 83, 90],
                3: [108, 125, 135],
                4: [155, 162, 175, 185, 189, 210, 218]
            }
            print(f"🔍 [DEBUG] physical策略返回: {result}")
            return result
            
        elif strategy_type == "uniform":
            print("✅ 使用内置uniform策略")
            selected_bands = [int(i * 218 / 28) for i in range(29)]
            result = {
                0: selected_bands[0:9],
                1: selected_bands[9:12],
                2: selected_bands[12:19],
                3: selected_bands[19:22],
                4: selected_bands[22:29]
            }
            print(f"🔍 [DEBUG] uniform策略返回: {result}")
            return result
            
        elif strategy_type == "custom":
            print(f"🔍 [DEBUG] 处理custom策略")
            if custom_txt_file is None:
                raise ValueError("使用custom策略时需要提供custom_txt_file参数")
            print(f"📄 加载自定义策略文件: {custom_txt_file}")
            strategy_data, _ = load_custom_strategy_from_txt(custom_txt_file)
            print(f"🔍 [DEBUG] custom策略返回: {strategy_data}")
            return strategy_data
        else:
            print(f"🔍 [DEBUG] 处理txt文件策略: {strategy_type}")
            
            # 🔥 这4个策略从txt文件加载
            txt_based_strategies = ["variance_importance", "correlation_importance", "mutual_info_importance", "spectral_physics_importance"]
            
            print(f"🔍 [DEBUG] 检查策略是否在txt列表中...")
            if strategy_type not in txt_based_strategies:
                available_strategies = ['physical', 'uniform'] + txt_based_strategies + ['custom']
                error_msg = f"未知策略: {strategy_type}。可用策略: {available_strategies}"
                print(f"❌ [DEBUG] {error_msg}")
                raise ValueError(error_msg)
            
            print(f"🔍 从txt文件加载策略: {strategy_type}")
            
            # 动态检测strategies目录
            possible_strategies_dirs = [
                # "/home/ai4sg/tang/Swin-UNETR-Clean/checkpoints/importance_analysis/strategies",  # Linux
                # "D:/wisc/SpecTran/codes/Swin-Unetr/Swin-UNETR-Clean/checkpoints/importance_analysis/strategies",  # Windows
                os.path.join(CHECKPOINT_DIR, "importance_analysis", "strategies"),  # 相对路径
            ]
            
            print(f"🔍 [DEBUG] 开始检查目录...")
            strategies_dir = None
            for i, possible_dir in enumerate(possible_strategies_dirs):
                print(f"🔍 [DEBUG] 检查目录 {i+1}/3: {possible_dir}")
                try:
                    if os.path.exists(possible_dir):
                        strategies_dir = possible_dir
                        print(f"✅ 找到strategies目录: {strategies_dir}")
                        break
                    else:
                        print(f"❌ 目录不存在: {possible_dir}")
                except Exception as e:
                    print(f"❌ [DEBUG] 检查目录时出错: {e}")
            
            if strategies_dir is None:
                print(f"❌ [DEBUG] 未找到strategies目录！")
                print(f"📁 当前CHECKPOINT_DIR: {CHECKPOINT_DIR}")
                print(f"📁 检查点目录内容:")
                try:
                    items = os.listdir(CHECKPOINT_DIR)
                    for item in items:
                        print(f"   - {item}")
                except Exception as e:
                    print(f"   无法读取: {e}")
                
                error_msg = f"未找到strategies目录。策略: {strategy_type}"
                print(f"❌ [DEBUG] 抛出错误: {error_msg}")
                raise FileNotFoundError(error_msg)
            
            print(f"🔍 [DEBUG] 继续处理策略文件...")
            
            # 🔥 添加完整的策略文件处理逻辑
            strategy_file_mapping = {
                "variance_importance": "variance_strategy.txt",
                "correlation_importance": "correlation_strategy.txt", 
                "mutual_info_importance": "mutual_info_strategy.txt",
                "spectral_physics_importance": "spectral_physics_strategy.txt"
            }
            
            print(f"📋 txt策略文件映射: {strategy_file_mapping}")
            
            if strategy_type in strategy_file_mapping:
                strategy_file = os.path.join(strategies_dir, strategy_file_mapping[strategy_type])
                print(f"🔍 查找策略文件: {strategy_file}")
                
                if os.path.exists(strategy_file):
                    print(f"📄 从文件加载策略: {strategy_file}")
                    try:
                        strategy_data, _ = load_custom_strategy_from_txt(strategy_file)
                        print(f"✅ 策略加载成功，包含 {len(strategy_data)} 个级别")
                        print(f"🔍 [DEBUG] 策略数据: {strategy_data}")
                        return strategy_data  # 🔥 关键：确保返回数据
                    except Exception as e:
                        print(f"❌ 策略文件解析失败: {e}")
                        import traceback
                        traceback.print_exc()
                        raise
                else:
                    # 显示可用文件并给出错误
                    print(f"❌ 策略文件不存在: {strategy_file}")
                    print(f"📁 strategies目录内容:")
                    try:
                        files = os.listdir(strategies_dir)
                        for f in files:
                            print(f"   - {f}")
                    except Exception as e:
                        print(f"   无法读取目录: {e}")
                    raise FileNotFoundError(f"策略文件不存在: {strategy_file}")
            else:
                # 这个分支理论上不会到达，因为上面已经检查过了
                raise ValueError(f"策略 {strategy_type} 不在txt加载列表中")
            
    except Exception as e:
        print(f"❌ [DEBUG] design_cascade_strategy函数出错: {e}")
        print(f"❌ [DEBUG] 错误类型: {type(e).__name__}")
        import traceback
        print("❌ [DEBUG] 函数内错误堆栈:")
        traceback.print_exc()
        raise  # 重新抛出异常
    

def get_all_trained_bands(checkpoint_dir, current_strategy, use_pretrained=False, pretrained_strategy=None):
    """获取可用的预训练波段"""
    trained_bands = []
    
    if not use_pretrained:
        print(f"🚫 禁用预训练模型，不扫描已训练波段")
        return trained_bands
    
    if not os.path.exists(checkpoint_dir):
        print(f"⚠️ 检查点目录不存在: {checkpoint_dir}")
        return trained_bands
    
    # 🎯 根据参数决定扫描策略
    scan_strategies = []
    
    if pretrained_strategy:
        # 只扫描指定策略
        scan_strategies = [pretrained_strategy]
        print(f"🔍 只扫描指定策略: {pretrained_strategy}")
    else:
        # 扫描所有策略
        try:
            scan_strategies = [d for d in os.listdir(checkpoint_dir) 
                             if os.path.isdir(os.path.join(checkpoint_dir, d))]
            print(f"🔍 扫描所有策略: {scan_strategies}")
        except Exception as e:
            print(f"⚠️ 扫描策略目录时出错: {e}")
            return trained_bands
    
    # 扫描指定策略的已训练波段
    for strategy in scan_strategies:
        strategy_path = os.path.join(checkpoint_dir, strategy)
        models_dir = os.path.join(strategy_path, "models")
        
        if os.path.exists(models_dir):
            try:
                for f in os.listdir(models_dir):
                    if f.startswith('band_') and f.endswith('_best_model.pth'):
                        try:
                            band_num = int(f.split('_')[1])
                            trained_bands.append(band_num)
                        except ValueError:
                            continue
            except Exception as e:
                print(f"⚠️ 扫描策略 {strategy} 时出错: {e}")
    
    trained_bands = sorted(list(set(trained_bands)))
    
    if trained_bands:
        print(f"📊 发现可用预训练波段: {len(trained_bands)} 个")
        print(f"   波段列表: {trained_bands}")
    else:
        print(f"📊 未发现可用预训练波段")
    
    return trained_bands

def get_current_strategy_trained_bands(checkpoint_dir, strategy_name):
    """获取当前策略已训练的波段"""
    trained_bands = []
    
    strategy_path = os.path.join(checkpoint_dir, strategy_name)
    models_dir = os.path.join(strategy_path, "models")
    
    if os.path.exists(models_dir):
        try:
            for f in os.listdir(models_dir):
                if f.startswith('band_') and f.endswith('_best_model.pth'):
                    try:
                        band_num = int(f.split('_')[1])
                        trained_bands.append(band_num)
                    except ValueError:
                        continue
        except Exception as e:
            print(f"⚠️ 扫描当前策略模型时出错: {e}")
    
    trained_bands = sorted(list(set(trained_bands)))
    
    if trained_bands:
        print(f"📊 当前策略已训练波段: {len(trained_bands)} 个 {trained_bands}")
    else:
        print(f"📊 当前策略未发现已训练波段")
    
    return trained_bands

def save_cascade_record(cascade_levels, strategy_name, base_dir):
    """保存级联记录到统一的txt文件"""
    record_file = os.path.join(base_dir, "cascade_levels.txt")
    
    # 如果文件已存在，追加内容；否则创建新文件
    mode = 'a' if os.path.exists(record_file) else 'w'
    
    with open(record_file, mode, encoding='utf-8') as f:
        if mode == 'w':
            f.write("# 级联训练波段级别记录\n")
            f.write(f"# 生成时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
            f.write("# 格式: Band_xxx -> Level_x (Strategy: strategy_name)\n")
            f.write("=" * 70 + "\n\n")
        
        f.write(f"# {strategy_name.upper()} 策略:\n")
        f.write(f"# 总级别数: {len(cascade_levels)}\n")
        f.write(f"# 总波段数: {sum(len(bands) for bands in cascade_levels.values())}\n")
        f.write("-" * 50 + "\n")
        
        # 写入每个波段的级别信息
        for level in sorted(cascade_levels.keys()):
            bands = cascade_levels[level]
            for band in sorted(bands):
                f.write(f"Band_{band:03d} -> Level_{level} (Strategy: {strategy_name})\n")
        
        f.write("\n" + "=" * 70 + "\n\n")
    
    print(f"📝 级联记录已追加到: {record_file}")
    return record_file

def save_training_summary(strategy_name, base_dir, cascade_levels, training_results):
    """保存训练总结到策略专用目录"""
    # 创建策略专用目录
    strategy_dir = os.path.join(base_dir, strategy_name)
    os.makedirs(strategy_dir, exist_ok=True)
    
    summary_file = os.path.join(strategy_dir, "training_summary.json")
    
    summary = {
        'strategy': strategy_name,
        'timestamp': datetime.now().isoformat(),
        'cascade_levels': cascade_levels,
        'total_bands': sum(len(bands) for bands in cascade_levels.values()),
        'total_levels': len(cascade_levels),
        'training_results': training_results,
        'best_bands': {
            'lowest_rmse': min(training_results.items(), key=lambda x: x[1].get('rmse', float('inf')))[0] if training_results else None,
            'lowest_mae': min(training_results.items(), key=lambda x: x[1].get('mae', float('inf')))[0] if training_results else None
        }
    }
    
    with open(summary_file, 'w', encoding='utf-8') as f:
        json.dump(summary, f, indent=2, ensure_ascii=False)
    
    print(f"📊 训练总结已保存到: {summary_file}")
    return summary_file

def main():
    print("🔍 [DEBUG] 进入main函数")
    
    parser = argparse.ArgumentParser(description='级联光谱重建训练')
    parser.add_argument('--strategy', type=str, default='physical',
                       choices=['physical', 'uniform', 'variance_importance', 
                               'correlation_importance', 'mutual_info_importance', 
                               'spectral_physics_importance', 'custom'],
                       help='级联策略类型 (physical/uniform:硬编码, 其他4个:txt文件)')
    parser.add_argument('--custom_txt', type=str, default=None,
                       help='自定义策略txt文件路径（仅在strategy=custom时使用）')
    parser.add_argument('--batch_size', type=int, default=12, help='批次大小')
    parser.add_argument('--device', type=str, default='cuda', help='训练设备')
    parser.add_argument('--start_level', type=int, default=0, help='开始级联层次')
    parser.add_argument('--end_level', type=int, default=4, help='结束级联层次')
    
    # 🆕 新增参数：数据类型选择
    parser.add_argument('--data_type', type=str, default='with_indices',
                       choices=['with_indices', 'original', 'repeated', 'raw'],
                       help='数据类型选择: with_indices=植被指数增强数据(默认), original=原始16通道数据, repeated=重复模式数据, raw=原始5通道数据(不堆叠)')
    
    # 🆕 新增参数：控制是否使用预训练模型
    parser.add_argument('--use_pretrained', action='store_true', default=False,
                       help='是否使用已有波段模型作为预训练（默认：从零开始）')
    parser.add_argument('--pretrained_strategy', type=str, default=None,
                       help='指定预训练模型来源策略（如果不指定，则在所有策略中查找）')
    parser.add_argument('--force_retrain', action='store_true', default=False,
                       help='强制重新训练已存在的波段模型（默认：跳过已训练波段）')
    
    # 🆕 新增参数：控制是否使用Anchor Head
    parser.add_argument('--use_anchor', action='store_true', default=False,
                       help='是否使用Spectral Anchor Head进行正则化')
    
    # 在 main() 函数的参数解析部分添加：
    parser.add_argument('--use_3d', action='store_true', default=False,
                       help='使用3D模式 (1, 128, 128, 16) 而不是2D模式 (16, 128, 128)')
    
    # 🆕 新增参数：环境选择
    parser.add_argument('--env', type=str, default='server', choices=['server', 'local'],
                       help='运行环境: server=使用config.py中的默认路径, local=使用当前目录相对路径')
    
    print("🔍 [DEBUG] 开始解析参数")
    args = parser.parse_args()
    print("🔍 [DEBUG] 参数解析完成")
    
    # 🔥 处理环境路径覆盖
    if args.env == 'local':
        print("🌍 检测到本地环境模式，正在更新路径配置...")
        current_dir = os.path.dirname(os.path.abspath(__file__)) # train/
        project_root = os.path.dirname(current_dir) # Swin-UNETR-Clean/
        
        global BASE_DIR, CHECKPOINT_DIR
        BASE_DIR = os.path.join(project_root, 'dataset')
        CHECKPOINT_DIR = os.path.join(project_root, 'checkpoints')
        
        print(f"   ✅ BASE_DIR 更新为: {BASE_DIR}")
        print(f"   ✅ CHECKPOINT_DIR 更新为: {CHECKPOINT_DIR}")
    else:
        print("🖥️ 使用默认(Server)路径配置")
    
    print(f"🔧 当前运行环境: {os.name}")
    print(f"📁 原始数据目录: {BASE_DIR}")
    print(f"📁 处理后数据目录: {BASE_DIR}")
    print(f"💾 模型目录: {CHECKPOINT_DIR}")
    
    # 🔥 修改：显示解析到的参数
    print(f"\n🎯 解析到的参数:")
    print(f"   策略: {args.strategy}")
    
    # 数据类型显示
    if args.data_type == 'with_indices':
        data_type_desc = "植被指数增强数据"
    elif args.data_type == 'repeated':
        data_type_desc = "重复模式数据 [0,0,0,0,1,1,1,2,2,2,3,3,3,4,4,4]"
    else:
        data_type_desc = "原始16通道数据"
    
    print(f"   数据类型: {data_type_desc}")
    print(f"   批次大小: {args.batch_size}")
    print(f"   设备: {args.device}")
    print(f"   级别范围: {args.start_level} - {args.end_level}")
    print(f"   使用预训练: {args.use_pretrained}")
    print(f"   强制重训: {args.force_retrain}")
    
    # 🔥 添加详细的策略加载调试
    print(f"\n🎯 开始加载策略: {args.strategy}")
    
    try:
        print("📝 进入策略加载逻辑...")
        
        # 确定策略名称
        if args.strategy == "custom":
            if not args.custom_txt:
                raise ValueError("使用custom策略时必须提供--custom_txt参数")
            
            print(f"📄 加载自定义策略文件: {args.custom_txt}")
            cascade_levels = design_cascade_strategy(args.strategy, args.custom_txt)
            _, strategy_name = load_custom_strategy_from_txt(args.custom_txt)
        else:
            print(f"📄 调用 design_cascade_strategy('{args.strategy}')...")
            cascade_levels = design_cascade_strategy(args.strategy)
            strategy_name = args.strategy
            print(f"📄 策略函数返回成功...")
        
        print(f"✅ 策略加载成功: {strategy_name}")
        print(f"📊 策略包含 {len(cascade_levels)} 个级别")
        print(f"📊 策略内容: {cascade_levels}")
        
    except Exception as e:
        print(f"❌ 策略加载失败: {e}")
        print(f"❌ 错误类型: {type(e).__name__}")
        import traceback
        print("❌ 完整错误堆栈:")
        traceback.print_exc()
        print("❌ 程序将退出")
        return  # 🔥 添加明确的退出点
    
    print("🔍 [DEBUG] 策略加载完成，继续后续流程...")
    
    # 🔥 修改：根据数据类型创建策略专用目录
    if args.data_type == 'with_indices':
        strategy_name_with_suffix = f"{strategy_name}_with_indices"
        data_description = "植被指数增强数据"
    elif args.data_type == 'repeated':
        strategy_name_with_suffix = f"{strategy_name}_repeated"
        data_description = "重复模式16通道数据 [0,0,0,0,1,1,1,2,2,2,3,3,3,4,4,4]"
    else:
        strategy_name_with_suffix = f"{strategy_name}_original"
        data_description = "原始16通道数据"
    
    print(f"🔍 [DEBUG] 创建策略目录: {strategy_name_with_suffix}")
    print(f"📁 将使用策略目录: {strategy_name_with_suffix}")
    
    # 创建策略专用目录
    strategy_dir = os.path.join(CHECKPOINT_DIR, strategy_name_with_suffix)
    os.makedirs(strategy_dir, exist_ok=True)
    print(f"🔍 [DEBUG] 策略目录创建完成: {strategy_dir}")
    
    # 创建子目录
    models_dir = os.path.join(strategy_dir, "models")
    tensorboard_dir = os.path.join(strategy_dir, "tensorboard_logs")
    os.makedirs(models_dir, exist_ok=True)
    os.makedirs(tensorboard_dir, exist_ok=True)
    print(f"🔍 [DEBUG] 子目录创建完成")
    
    try:
        writer = SummaryWriter(tensorboard_dir)
        print(f"🔍 [DEBUG] TensorBoard writer创建成功")
    except Exception as e:
        print(f"⚠️ TensorBoard writer创建失败: {e}")
        writer = None
    
    print(f"🚀 开始 {strategy_name_with_suffix} 策略级联训练")
    print(f"🌱 使用数据类型: {data_description}")
    print(f"📁 策略目录: {strategy_dir}")
    print(f"📁 模型目录: {models_dir}")
    print(f"📁 日志目录: {tensorboard_dir}")
    
    # 显示策略详情
    print(f"\n📊 {strategy_name} 策略详情:")
    total_bands = 0
    for level in sorted(cascade_levels.keys()):
        bands = cascade_levels[level]
        total_bands += len(bands)
        print(f"   Level {level}: {len(bands)} 个波段 {bands}")
    print(f"   总计: {total_bands} 个波段")
    
    print(f"🔍 [DEBUG] 开始保存级联记录...")
    # 保存级联记录到策略目录
    try:
        save_cascade_record(cascade_levels, strategy_name, strategy_dir)
        print(f"🔍 [DEBUG] 级联记录保存完成")
    except Exception as e:
        print(f"⚠️ 保存级联记录失败: {e}")
    
    # 训练设备
    print(f"🔍 [DEBUG] 初始化训练设备...")
    device = torch.device(args.device if torch.cuda.is_available() else 'cpu')
    if torch.cuda.is_available():
        print(f"🎮 使用GPU: {torch.cuda.get_device_name(0)}")
    else:
        print(f"💻 使用CPU")
    print(f"🔍 [DEBUG] 设备初始化完成: {device}")
    
    # 🔥 显示训练模式
    print(f"\n🎯 训练模式配置:")
    print(f"   使用预训练模型: {'✅' if args.use_pretrained else '❌'}")
    if args.use_pretrained:
        if args.pretrained_strategy:
            print(f"   预训练来源策略: {args.pretrained_strategy}")
        else:
            print(f"   预训练来源策略: 自动搜索所有策略")
    print(f"   强制重新训练: {'✅' if args.force_retrain else '❌'}")
    
    print(f"🔍 [DEBUG] 开始获取预训练波段...")
    # 获取可用的预训练波段
    try:
        available_pretrained_bands = get_all_trained_bands(
            CHECKPOINT_DIR, 
            strategy_name_with_suffix,
            args.use_pretrained,
            args.pretrained_strategy
        )
        print(f"🔍 [DEBUG] 预训练波段获取完成: {len(available_pretrained_bands)} 个")
    except Exception as e:
        print(f"⚠️ 获取预训练波段失败: {e}")
        available_pretrained_bands = []
    
    print(f"🔍 [DEBUG] 开始获取当前策略已训练波段...")
    # 获取当前策略已训练的波段
    try:
        current_strategy_bands = get_current_strategy_trained_bands(CHECKPOINT_DIR, strategy_name_with_suffix)
        print(f"🔍 [DEBUG] 当前策略已训练波段: {len(current_strategy_bands)} 个")
    except Exception as e:
        print(f"⚠️ 获取当前策略波段失败: {e}")
        current_strategy_bands = []
    
    training_results = {}
    
    print(f"🔍 [DEBUG] 开始主训练循环...")
    print(f"🔍 [DEBUG] 级别范围: {args.start_level} 到 {args.end_level}")
    
    try:
        for level in range(args.start_level, args.end_level + 1):
            print(f"🔍 [DEBUG] 处理级别 {level}")
            
            if level not in cascade_levels:
                print(f"🔍 [DEBUG] 级别 {level} 不在策略中，跳过")
                continue
                
            bands_to_train = cascade_levels[level]
            print(f"\n🎯 开始训练级联层次 {level}，包含 {len(bands_to_train)} 个波段")
            print(f"波段列表: {bands_to_train}")
            
            for i, band_idx in enumerate(bands_to_train):
                print(f"🔍 [DEBUG] 处理波段 {band_idx} ({i+1}/{len(bands_to_train)})")
                
                try:
                    # 🔥 检查是否跳过已训练的波段
                    if not args.force_retrain and band_idx in current_strategy_bands:
                        print(f"⏭️ 跳过波段 {band_idx}（已训练，使用 --force_retrain 强制重训）")
                        continue
                    
                    print(f"🔍 [DEBUG] 开始寻找预训练模型...")
                    # 寻找预训练模型
                    pretrained_path = find_best_pretrained_model(
                        band_idx, 
                        available_pretrained_bands, 
                        CHECKPOINT_DIR, 
                        strategy_name_with_suffix,
                        args.use_pretrained,
                        args.pretrained_strategy
                    )
                    print(f"🔍 [DEBUG] 预训练模型路径: {pretrained_path}")
                    
                    print(f"🔍 [DEBUG] 开始训练波段 {band_idx}...")
                    # 🔥 修改：传递data_type参数
                    model_path, results = train_single_band_model(
                        target_band_idx=band_idx,
                        cascade_level=level,
                        batch_size=args.batch_size,
                        device=device,
                        pretrained_model_path=pretrained_path,
                        strategy_dir=models_dir,
                        writer=writer,
                        data_type=args.data_type,
                        use_3d=args.use_3d,  # 🔥 传递这个参数
                        use_anchor=args.use_anchor # 🔥 传递这个参数
                    )
                    
                    # 记录结果
                    training_results[f"band_{band_idx:03d}"] = results
                    current_strategy_bands.append(band_idx)
                    
                    print(f"✅ 波段 {band_idx} 训练完成")
                    
                except Exception as e:
                    print(f"❌ 波段 {band_idx} 训练失败: {e}")
                    import traceback
                    traceback.print_exc()
                    continue
            
            print(f"🎉 级联层次 {level} 完成!")
    
        print(f"🔍 [DEBUG] 开始保存训练总结...")
        # 保存训练总结
        try:
            save_training_summary(strategy_name_with_suffix, CHECKPOINT_DIR, cascade_levels, training_results)
            print(f"🔍 [DEBUG] 训练总结保存完成")
        except Exception as e:
            print(f"⚠️ 保存训练总结失败: {e}")
        
        print(f"\n🎉 {strategy_name} 策略级联训练全部完成!")
        print(f"📁 策略模型文件: {models_dir}")
        print(f"📝 级联记录: {strategy_dir}/cascade_levels.txt")
        print(f"📊 策略训练总结: {strategy_dir}/training_summary.json")
        print(f"📈 策略TensorBoard: {tensorboard_dir}")
        
    except Exception as e:
        print(f"❌ 训练过程出错: {e}")
        import traceback
        traceback.print_exc()
    finally:
        print(f"🔍 [DEBUG] 清理资源...")
        if writer:
            writer.close()
        print(f"🔍 [DEBUG] main函数结束")

# 🔥 确保在文件末尾有这个调用
if __name__ == "__main__":
    main()

