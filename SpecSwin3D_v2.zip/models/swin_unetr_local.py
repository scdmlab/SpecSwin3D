"""
本地可编辑的 SwinUNETR 包装器。

目的：
- 在本地代码库中提供一个可修改的模型文件，接口与 MONAI 的 SwinUNETR 保持兼容，便于你在本地对模型结构做实验。
- 提供便捷的部分加载函数（只加载匹配的权重）以便迁移已有 checkpoint。

用法示例：
    from models.swin_unetr_local import SwinUNETR_Local, load_state_partial
    model = SwinUNETR_Local(in_channels=16, img_size=(128,128), spatial_dims=2, feature_size=48)
    load_state_partial(model, '/path/to/checkpoint.pth')

注意：该文件默认依赖 MONAI 中的 SwinUNETR 实现；如果你想完全脱离 MONAI，可把 MONAI 的源代码（或其相关模块）复制到本地并在此处直接引入/修改。
"""
from typing import Optional
import torch
import torch.nn as nn

try:
    # 优先尝试从本地 third_party 导入，这样你可以随意修改源码
    from third_party.monai_local.swin_unetr import SwinUNETR
    print("✅ 已加载本地 SwinUNETR (third_party/monai_local/swin_unetr.py)")
except ImportError as e:
    # 如果本地没有，则回退到系统安装的 monai
    print(f"⚠️ 未找到本地 SwinUNETR ({e})，回退到系统 MONAI 安装")
    from monai.networks.nets import SwinUNETR


class SwinUNETR_Local(nn.Module):
    def __init__(self, in_channels=16, out_channels=1, img_size=(128, 128), spatial_dims=2, feature_size=48, use_checkpoint=False, extra_head: Optional[bool]=False, use_anchor_head=False, anchor_k=10, window_size=7, patch_size=2, downsample="combinatorial"):
        super().__init__()
        if SwinUNETR is None:
            raise ImportError('monai.SwinUNETR 未安装或无法导入。请在环境中安装 monai 或把 MONAI 的实现复制到项目中。')

        self.base = SwinUNETR(
            in_channels=in_channels,
            out_channels=out_channels,  # 这里传递out_channels
            feature_size=feature_size,
            spatial_dims=spatial_dims,
            use_checkpoint=use_checkpoint,
            use_anchor_head=use_anchor_head,
            anchor_k=anchor_k,
            window_size=window_size,
            patch_size=patch_size,
            downsample=downsample
        )
        
        self.use_anchor_head = use_anchor_head

        self.extra_head = extra_head
        if extra_head:
            if spatial_dims == 2:
                self.head = nn.Sequential(
                    nn.Conv2d(1, 1, kernel_size=3, padding=1),
                    nn.Sigmoid()
                )
            else:
                self.head = nn.Sequential(
                    nn.Conv3d(1, 1, kernel_size=3, padding=1),
                    nn.Sigmoid()
                )

    def forward(self, x):
        out = self.base(x)
        
        anchor_out = None
        if self.use_anchor_head:
            # If use_anchor_head is True, base returns (logits, anchor_out)
            x_out, anchor_out = out
        else:
            x_out = out
            
        if self.extra_head:
            x_out = self.head(x_out)
            
        if self.use_anchor_head:
            return x_out, anchor_out
        return x_out


def load_state_partial(model: nn.Module, ckpt_path: str, map_location='cpu'):
    """部分加载 checkpoint：仅加载与 model 中参数名和形状匹配的权重。

    返回未匹配的 key 列表。
    """
    ckpt = torch.load(ckpt_path, map_location=map_location)
    state = ckpt.get('model_state_dict', ckpt)
    model_state = model.state_dict()

    matched = {}
    unmatched = []
    for k, v in state.items():
        if k in model_state and v.size() == model_state[k].size():
            matched[k] = v
        else:
            unmatched.append(k)

    model_state.update(matched)
    model.load_state_dict(model_state)
    print(f"Loaded {len(matched)} keys, unmatched {len(unmatched)} (example: {unmatched[:10]})")
    return unmatched


def print_param_counts(model: nn.Module):
    total = sum(p.numel() for p in model.parameters())
    trainable = sum(p.numel() for p in model.parameters() if p.requires_grad)
    print(f"params total: {total:,}, trainable: {trainable:,}")
