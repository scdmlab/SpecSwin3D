﻿# data_preprocessing/input-label.py
import os
import glob
import tifffile
import torch
import numpy as np
import sys

# Add parent directory to path以导入config
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from config import TIF_DIR, BASE_DIR

# === 设置路径 ===
tif_dir = TIF_DIR
out_input_dir = os.path.join(BASE_DIR, "input")
out_label_dir = os.path.join(BASE_DIR, "label")
os.makedirs(out_input_dir, exist_ok=True)
os.makedirs(out_label_dir, exist_ok=True)

# 选用的输入波段
input_bands = [30, 20, 9, 40, 52]
label_band_indices = [i for i in range(224) if i not in input_bands]

# 获取所有 .tif 文件
tif_files = sorted(glob.glob(os.path.join(tif_dir, "patch_*.tif")))
print("🗂️ Found {} .tif files.".format(len(tif_files)))

def normalize_data(data):
    """简单有效的归一化：使用1%-99%分位数到[0,1]"""
    p1 = np.percentile(data, 1)
    p99 = np.percentile(data, 99)
    normalized = np.clip((data - p1) / (p99 - p1 + 1e-8), 0, 1)
    return normalized.astype(np.float32), float(p1), float(p99)

for i, tif_path in enumerate(tif_files):
    full_img = tifffile.imread(tif_path)  # shape: (H, W, 224) or (224, H, W)
    shape = full_img.shape

    # 如果 shape 是 (H, W, 224)，转为 (224, H, W)
    if shape[0] != 224:
        if shape[-1] == 224:
            full_img = np.transpose(full_img, (2, 0, 1))  # [H, W, C] → [C, H, W]
        else:
            print("❗ 跳过 {}：无法识别的 shape {}".format(tif_path, shape))
            continue

    # 裁剪中间区域
    full_img = full_img[:, :128, :128]

    # 构造输入和标签
    input_tensor = full_img[input_bands, :, :]
    label_tensor = full_img[label_band_indices, :, :]

    # === 归一化处理 ===
    # 对输入进行归一化
    normalized_input = np.zeros_like(input_tensor)
    input_norm_params = []
    for idx in range(len(input_bands)):
        normalized_input[idx], p1, p99 = normalize_data(input_tensor[idx])
        input_norm_params.append({'p1': p1, 'p99': p99})
    
    # 对标签进行归一化
    normalized_label = np.zeros_like(label_tensor)
    label_norm_params = []
    for idx in range(len(label_band_indices)):
        normalized_label[idx], p1, p99 = normalize_data(label_tensor[idx])
        label_norm_params.append({'p1': p1, 'p99': p99})

    base = os.path.splitext(os.path.basename(tif_path))[0]

    # 保存 input 为 dict（包含归一化参数）
    torch.save({
        "input": torch.tensor(normalized_input),
        "band_indices": input_bands,
        "norm_params": input_norm_params
    }, os.path.join(out_input_dir, base + ".pt"))

    # 保存 label 为 dict（包含归一化参数）
    torch.save({
        "label": torch.tensor(normalized_label),
        "band_indices": label_band_indices,
        "norm_params": label_norm_params
    }, os.path.join(out_label_dir, base + ".pt"))

    if (i + 1) % 20 == 0:
        print("[{}/{}] 已处理归一化".format(i+1, len(tif_files)))

print("\n🎉 所有样本生成完成（已归一化到[0,1]范围）")

# 验证归一化效果
if len(tif_files) > 0:
    sample_input = torch.load(os.path.join(out_input_dir, os.path.splitext(os.path.basename(tif_files[0]))[0] + ".pt"))
    sample_label = torch.load(os.path.join(out_label_dir, os.path.splitext(os.path.basename(tif_files[0]))[0] + ".pt"))
    
    print("\n🔍 归一化验证:")
    print("   输入范围: [{:.3f}, {:.3f}]".format(sample_input['input'].min(), sample_input['input'].max()))
    print("   标签范围: [{:.3f}, {:.3f}]".format(sample_label['label'].min(), sample_label['label'].max()))
