﻿import os
import glob
import torch
from tqdm import tqdm
import sys
import numpy as np

# 在 data_preprocessing/ 文件夹内的文件中使用这个导入
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from config import BASE_DIR

def restack_input_bands_repeated():
    """
    重新堆叠input文件夹中的数据
    原始5个波段: [30, 20, 9, 40, 52] -> 16个波段: 
    [0,0,0,0,1,1,1,2,2,2,3,3,3,4,4,4] 模式
    即: [30,30,30,30,20,20,20,9,9,9,40,40,40,52,52,52]
    """
    
    # 定义路径 - 使用配置文件 ✅
    input_dir = os.path.join(BASE_DIR, "input")
    output_dir = os.path.join(BASE_DIR, "input_restacked_16_repeated")
    
    # 创建输出目录
    os.makedirs(output_dir, exist_ok=True)
    
    # 新的重排索引: [0,0,0,0,1,1,1,2,2,2,3,3,3,4,4,4]
    repeated_indices = [0, 0, 0, 0, 1, 1, 1, 2, 2, 2, 3, 3, 3, 4, 4, 4]
    
    # 获取所有.pt文件
    pt_files = sorted(glob.glob(os.path.join(input_dir, "*.pt")))
    
    if not pt_files:
        print("❌ 在input文件夹中没有找到.pt文件")
        print("📁 请检查路径: {}".format(input_dir))
        return
    
    print("🔄 开始重新堆叠 {} 个文件".format(len(pt_files)))
    print("📁 输入目录: {}".format(input_dir))
    print("📁 输出目录: {}".format(output_dir))
    print("🔀 波段重排序: 原始5个波段 -> 16个波段")
    print("   重复模式: [0,0,0,0,1,1,1,2,2,2,3,3,3,4,4,4]")
    print("   对应波段: [30,30,30,30,20,20,20,9,9,9,40,40,40,52,52,52]")
    print("   重排索引: {}".format(repeated_indices))
    print()
    
    success_count = 0
    error_count = 0
    
    # 处理每个文件
    for pt_file in tqdm(pt_files, desc="处理文件"):
        try:
            # 加载原始数据
            data = torch.load(pt_file, map_location='cpu')
            
            # 检查数据格式
            if not isinstance(data, dict) or 'input' not in data:
                print("❌ 跳过文件 {}: 数据格式不正确".format(os.path.basename(pt_file)))
                error_count += 1
                continue
            
            # 获取原始张量
            original_tensor = data['input']  # 形状: [5, 128, 128]
            
            # 验证张量形状
            if len(original_tensor.shape) != 3 or original_tensor.shape[0] != 5:
                print("❌ 跳过文件 {}: 张量形状不是[5, H, W]，实际为{}".format(
                    os.path.basename(pt_file), original_tensor.shape))
                error_count += 1
                continue
            
            # 按照新的重复模式重排
            restacked_tensor = original_tensor[repeated_indices]  # 形状: [16, H, W]
            
            # 创建新的数据字典
            new_data = {
                'input': restacked_tensor,
                'original_band_indices': [30, 20, 9, 40, 52],  # 原始波段索引
                'restacked_band_info': {
                    'pattern': 'repeated_4x_each',
                    'channels_0_3': [30, 30, 30, 30],    # Band 30 重复4次
                    'channels_4_6': [20, 20, 20],        # Band 20 重复3次
                    'channels_7_9': [9, 9, 9],           # Band 9 重复3次
                    'channels_10_12': [40, 40, 40],      # Band 40 重复3次
                    'channels_13_15': [52, 52, 52],      # Band 52 重复3次
                    'full_sequence': [30, 30, 30, 30, 20, 20, 20, 9, 9, 9, 40, 40, 40, 52, 52, 52]
                },
                'wavelengths': {
                    'Band_30': '647nm (Red)',
                    'Band_20': '550nm (Green)',
                    'Band_9': '443nm (Blue)',
                    'Band_40': '723nm (Red Edge)',
                    'Band_52': '840nm (NIR)'
                },
                'restack_indices': repeated_indices,
                'restack_pattern': '[0,0,0,0,1,1,1,2,2,2,3,3,3,4,4,4]',
                'design_principle': 'Each original band repeated multiple times for enhanced feature learning'
            }
            
            # 保存新文件
            output_file = os.path.join(output_dir, os.path.basename(pt_file))
            torch.save(new_data, output_file)
            
            success_count += 1
            
        except Exception as e:
            print("❌ 处理文件 {} 时出错: {}".format(os.path.basename(pt_file), e))
            error_count += 1
    
    print("\n✅ 处理完成!")
    print("   成功处理: {} 个文件".format(success_count))
    print("   失败: {} 个文件".format(error_count))
    print("   输出目录: {}".format(output_dir))
    
    # 验证第一个输出文件
    if success_count > 0:
        verify_first_file(output_dir)

def verify_first_file(output_dir):
    """验证第一个输出文件的格式"""
    pt_files = sorted(glob.glob(os.path.join(output_dir, "*.pt")))
    if not pt_files:
        return
    
    try:
        data = torch.load(pt_files[0], map_location='cpu')
        print("\n🔍 验证第一个输出文件: {}".format(os.path.basename(pt_files[0])))
        print("   数据类型: {}".format(type(data)))
        print("   字典键: {}".format(list(data.keys())))
        
        if 'input' in data:
            tensor = data['input']
            print("   张量形状: {}".format(tensor.shape))
            print("   数据类型: {}".format(tensor.dtype))
            print("   数值范围: [{:.4f}, {:.4f}]".format(tensor.min().item(), tensor.max().item()))
            
            # 检查重复模式
            if tensor.shape[0] == 16:
                print("\n📊 各通道数值范围 (重复模式验证):")
                
                # 验证Band 30 (红光) - 前4个通道
                band_30_channels = tensor[0:4]
                print(f"   通道 0-3 (Band 30, 647nm Red): 重复4次")
                for i in range(4):
                    print(f"     通道 {i}: [{tensor[i].min():.4f}, {tensor[i].max():.4f}]")
                    if i > 0:
                        is_identical = torch.allclose(tensor[0], tensor[i])
                        print(f"     与通道0相同: {is_identical}")
                
                # 验证Band 20 (绿光) - 通道4-6
                print(f"   通道 4-6 (Band 20, 550nm Green): 重复3次")
                for i in range(4, 7):
                    print(f"     通道 {i}: [{tensor[i].min():.4f}, {tensor[i].max():.4f}]")
                    if i > 4:
                        is_identical = torch.allclose(tensor[4], tensor[i])
                        print(f"     与通道4相同: {is_identical}")
                
                # 验证Band 9 (蓝光) - 通道7-9
                print(f"   通道 7-9 (Band 9, 443nm Blue): 重复3次")
                for i in range(7, 10):
                    print(f"     通道 {i}: [{tensor[i].min():.4f}, {tensor[i].max():.4f}]")
                    if i > 7:
                        is_identical = torch.allclose(tensor[7], tensor[i])
                        print(f"     与通道7相同: {is_identical}")
                
                # 验证Band 40 (红边) - 通道10-12
                print(f"   通道 10-12 (Band 40, 723nm Red Edge): 重复3次")
                for i in range(10, 13):
                    print(f"     通道 {i}: [{tensor[i].min():.4f}, {tensor[i].max():.4f}]")
                    if i > 10:
                        is_identical = torch.allclose(tensor[10], tensor[i])
                        print(f"     与通道10相同: {is_identical}")
                
                # 验证Band 52 (近红外) - 通道13-15
                print(f"   通道 13-15 (Band 52, 840nm NIR): 重复3次")
                for i in range(13, 16):
                    print(f"     通道 {i}: [{tensor[i].min():.4f}, {tensor[i].max():.4f}]")
                    if i > 13:
                        is_identical = torch.allclose(tensor[13], tensor[i])
                        print(f"     与通道13相同: {is_identical}")
        
        if 'restacked_band_info' in data:
            print("\n   📋 重排信息:")
            band_info = data['restacked_band_info']
            if 'full_sequence' in band_info:
                print(f"   完整序列: {band_info['full_sequence']}")
            if 'pattern' in band_info:
                print(f"   重排模式: {band_info['pattern']}")
            
    except Exception as e:
        print("❌ 验证文件时出错: {}".format(e))

def compare_with_original():
    """对比原始数据和重排后的数据"""
    input_dir = os.path.join(BASE_DIR, "input")
    output_dir = os.path.join(BASE_DIR, "input_restacked_16_repeated")
    
    # 获取第一个文件进行对比
    input_files = sorted(glob.glob(os.path.join(input_dir, "*.pt")))
    output_files = sorted(glob.glob(os.path.join(output_dir, "*.pt")))
    
    if not input_files or not output_files:
        print("❌ 找不到对比文件")
        return
    
    try:
        # 加载原始和重排后的数据
        original_data = torch.load(input_files[0], map_location='cpu')
        restacked_data = torch.load(output_files[0], map_location='cpu')
        
        original_tensor = original_data['input']  # [5, H, W]
        restacked_tensor = restacked_data['input']  # [16, H, W]
        
        print("\n🔍 数据对比分析:")
        print(f"   原始数据形状: {original_tensor.shape}")
        print(f"   重排数据形状: {restacked_tensor.shape}")
        
        # 验证重排的正确性
        repeated_indices = [0, 0, 0, 0, 1, 1, 1, 2, 2, 2, 3, 3, 3, 4, 4, 4]
        
        print("\n✅ 重排验证:")
        all_correct = True
        for i, orig_idx in enumerate(repeated_indices):
            is_identical = torch.allclose(original_tensor[orig_idx], restacked_tensor[i])
            status = "✅" if is_identical else "❌"
            print(f"   通道 {i:2d} <- 原始波段 {orig_idx} {status}")
            if not is_identical:
                all_correct = False
        
        if all_correct:
            print("\n🎉 重排验证通过！所有通道都正确对应原始波段")
        else:
            print("\n⚠️ 重排验证失败！请检查代码")
        
    except Exception as e:
        print(f"❌ 对比过程出错: {e}")

if __name__ == "__main__":
    print("🚀 开始创建重复模式的16通道数据")
    print("📋 重排模式: [0,0,0,0,1,1,1,2,2,2,3,3,3,4,4,4]")
    print("🎯 设计理念: 每个原始波段重复多次，增强特征学习\n")
    
    # 执行重排
    restack_input_bands_repeated()
    
    # 执行对比验证
    print("\n" + "="*60)
    compare_with_original()
