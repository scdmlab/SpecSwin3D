﻿import os
import glob
import torch
from tqdm import tqdm
import sys

# 在 data_preprocessing/ 文件夹内的文件中使用这个导入
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from config import BASE_DIR

def restack_input_bands():
    """
    重新堆叠input文件夹中的数据
    原始5个波段: [30, 20, 9, 40, 52] -> 16个波段: [30, 20, 9, 40, 52, 20, 40, 30, 9, 52, 30, 52, 40, 9, 20, 30]
    """
    
    # 定义路径 - 使用配置文件 ✅
    input_dir = os.path.join(BASE_DIR, "input")
    output_dir = os.path.join(BASE_DIR, "input_restacked_16")
    
    # 创建输出目录
    os.makedirs(output_dir, exist_ok=True)
    
    # 原始波段索引: [30, 20, 9, 40, 52] (对应张量的通道索引 [0, 1, 2, 3, 4])
    # 目标波段顺序按模式 1234524135154321: [30, 20, 9, 40, 52, 20, 40, 30, 9, 52, 30, 52, 40, 9, 20, 30]
    # 对应的张量通道索引: [0, 1, 2, 3, 4, 1, 3, 0, 2, 4, 0, 4, 3, 2, 1, 0]
    restack_indices = [0, 1, 2, 3, 4, 1, 3, 0, 2, 4, 0, 4, 3, 2, 1, 0]
    
    # 获取所有.pt文件
    pt_files = sorted(glob.glob(os.path.join(input_dir, "*.pt")))
    
    if not pt_files:
        print("❌ 在input文件夹中没有找到.pt文件")
        print("📁 请检查路径: {}".format(input_dir))
        return
    
    print("🔄 开始重新堆叠 {} 个文件".format(len(pt_files)))
    print("📁 输入目录: {}".format(input_dir))
    print("📁 输出目录: {}".format(output_dir))
    print("🔀 波段重排序: 原始5个波段 -> 16个波段")
    print("   波段模式: 1234524135154321")
    print("   索引映射: {}".format(restack_indices))
    print()
    
    success_count = 0
    error_count = 0
    
    # 处理每个文件
    for pt_file in tqdm(pt_files, desc="处理文件"):
        try:
            # 加载原始数据
            data = torch.load(pt_file, map_location='cpu')
            
            # 检查数据格式
            if not isinstance(data, dict) or 'input' not in data:
                print("❌ 跳过文件 {}: 数据格式不正确".format(os.path.basename(pt_file)))
                error_count += 1
                continue
            
            # 获取原始张量
            original_tensor = data['input']  # 形状: [5, 128, 128]
            
            # 验证张量形状
            if len(original_tensor.shape) != 3 or original_tensor.shape[0] != 5:
                print("❌ 跳过文件 {}: 张量形状不是[5, H, W]，实际为{}".format(
                    os.path.basename(pt_file), original_tensor.shape))
                error_count += 1
                continue
            
            # 重新堆叠波段
            restacked_tensor = original_tensor[restack_indices]  # 形状: [16, 128, 128]
            
            # 创建新的数据字典
            new_data = {
                'input': restacked_tensor,
                'original_band_indices': [30, 20, 9, 40, 52],  # 原始波段索引
                'restacked_band_indices': [30, 20, 9, 40, 52, 20, 40, 30, 9, 52, 30, 52, 40, 9, 20, 30],  # 重排后的波段索引
                'restack_mapping': restack_indices,  # 张量索引映射
                'restack_pattern': '1234524135154321'  # 重排模式
            }
            
            # 保存新文件
            output_file = os.path.join(output_dir, os.path.basename(pt_file))
            torch.save(new_data, output_file)
            
            success_count += 1
            
        except Exception as e:
            print("❌ 处理文件 {} 时出错: {}".format(os.path.basename(pt_file), e))
            error_count += 1
    
    print("\n✅ 处理完成!")
    print("   成功处理: {} 个文件".format(success_count))
    print("   失败: {} 个文件".format(error_count))
    print("   输出目录: {}".format(output_dir))
    
    # 验证第一个输出文件
    if success_count > 0:
        verify_first_file(output_dir)

def verify_first_file(output_dir):
    """验证第一个输出文件的格式"""
    pt_files = sorted(glob.glob(os.path.join(output_dir, "*.pt")))
    if not pt_files:
        return
    
    try:
        data = torch.load(pt_files[0], map_location='cpu')
        print("\n🔍 验证第一个输出文件: {}".format(os.path.basename(pt_files[0])))
        print("   数据类型: {}".format(type(data)))
        print("   字典键: {}".format(list(data.keys())))
        
        if 'input' in data:
            tensor = data['input']
            print("   张量形状: {}".format(tensor.shape))
            print("   数据类型: {}".format(tensor.dtype))
            print("   数值范围: [{:.4f}, {:.4f}]".format(tensor.min().item(), tensor.max().item()))
        
        if 'restacked_band_indices' in data:
            print("   重排后波段索引: {}".format(data['restacked_band_indices']))
        
        if 'restack_pattern' in data:
            print("   重排模式: {}".format(data['restack_pattern']))
            
        if 'restack_mapping' in data:
            print("   张量索引映射: {}".format(data['restack_mapping']))
            
    except Exception as e:
        print("❌ 验证文件时出错: {}".format(e))

if __name__ == "__main__":
    restack_input_bands()
